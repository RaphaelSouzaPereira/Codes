package Temperatura;

import com.senac.SimpleJava.Console;

public class Termometro {

	public void run() {
		boolean exit = true;
		Farenheit f = new Farenheit();
		Celsius c = new Celsius();
		do {
			Console.println("Digite um valor para a temperatura Celsius ou Farenheit: ");
			String temperatura = Console
					.readLine("Digite F depois do numero para Farenheit ou C depois do numero para Celius: ");
			for (int i = 0; i < temperatura.length(); i++) {
				if (temperatura.charAt(i) == 'F') {
					f.setFarenheit(Double.parseDouble(temperatura.replaceAll("F", "")));
					Console.println(f.getFarenheit());
				}
				if (temperatura.charAt(i) == 'C') {
					c.setCelsius(Double.parseDouble(temperatura.replaceAll("C", "")));
					Console.println(c.getCelsius());
				}
			}
			int escolha = Console.readInt(
					"1 para mudar de Celsius para Farenheit;\n 2 de Farenheit para Celsius;\n 3 para sair:\n");
			if (escolha == 1) {
				f.celsiouParaFarenheit(c.getCelsius());
				Console.println("A sua temperatura �: " + f.getFarenheit() + "F");
			}
			if (escolha == 2) {
				c.ferenheitParaCelsius(f.getFarenheit());
				Console.println("A sua temperatura �: " + c.getCelsius() + "C");
			}
			if (escolha == 3) {
				for (int i = 0; i < temperatura.length(); i++) {
					if (temperatura.charAt(i) == 'F' || temperatura.charAt(i) == 'f') {
						Console.println("A sua temperatura �: " + f.getFarenheit() + "F");
					}
					if (temperatura.charAt(i) == 'C' || temperatura.charAt(i) == 'c') {
						Console.println("A sua temperatura �: " + c.getCelsius() + "C");
					}
				}
				exit = false;
			}

		} while (exit);

	}

}
