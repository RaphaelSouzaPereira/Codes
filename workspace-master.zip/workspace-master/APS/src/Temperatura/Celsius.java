package Temperatura;

public class Celsius {
	
	private Double celsius;

	public Double getCelsius() {
		return this.celsius;
	}

	public void setCelsius(Double celsius) {
		this.celsius = celsius;
	}

	public void ferenheitParaCelsius(Double farenheit) {
		this.celsius = ((farenheit - 32)/1.8);
	}
	

}
