package Temperatura;

public class Farenheit {

	private Double farenheit;
	

	public Double getFarenheit() {
		return this.farenheit;
	}

	public void setFarenheit(Double farenheit) {
		this.farenheit = farenheit;
	}
	
	public void celsiouParaFarenheit(Double celsius) {
		this.farenheit = ((1.8 * celsius)+32.0);
	}
}
