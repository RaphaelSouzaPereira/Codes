package Circulos;

public class circulo {
	int raio=0;
	public void Circulo(int raio){
		this.raio = raio;
	}

	public void setRaio(int readInt) {
		this.raio = readInt;
		
	}
	public double getRaio(){
		return this.raio;
	
	}
	
	public double getArea(){
		double area = Math.PI*(raio*raio);
		return area;
		
	}

	public double calculaCircuferencia(){
		double circuferencia = (2*Math.PI)*raio;
		return circuferencia;
	}


}

