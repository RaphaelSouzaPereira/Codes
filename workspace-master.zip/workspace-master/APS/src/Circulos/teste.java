package Circulos;

import com.senac.SimpleJava.Console;


public class teste {

	public void run() {
		circulo c1 = new circulo();
		c1.setRaio(Console.readInt("Digite o valor do raio do primeiro circulo:"));
		circulo c2 = new circulo();
		c2.setRaio(Console.readInt("Digite o valor do raio do segundo circulo:"));
		int area = Console.readInt("Informe o tamanho da area da linha: ");
		double distancia = area - (c1.getArea() + c2.getArea());
		double pontoAfastamento = distancia * (-1);
		int percorrido = 0;
		boolean primeiraToca = true;
		Console.println("A area C1: " + Math.round(c1.getArea()) + "\n A circuferencia C1: " + Math.round(c1.calculaCircuferencia()));
		Console.println("A area C2: " + Math.round(c2.getArea()) + "\n A circuferencia C2: " + Math.round(c2.calculaCircuferencia()));

		do {
			if (percorrido > area) {
				
				if (distancia <= percorrido) {
					if (primeiraToca) {
						Console.println("Se tocaram");
						primeiraToca = false;
					}
					if (distancia <= pontoAfastamento) {
						Console.println("Estao sobrepostos");

					}
					if (distancia >= pontoAfastamento) {
						Console.println("Se afastaram");
					}

					
					
				}
				percorrido += 2;
				distancia -= 2;
			}

		} while (percorrido < area);

		Console.println("Percorreram toda a area");
	}
}
