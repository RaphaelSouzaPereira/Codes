package Signos;

import com.senac.SimpleJava.Console;
import java.time.LocalDate;
import java.time.Period;

public class Pessoa {
	public void run() {

		int ano = Console.readInt("Ano: ");
		int mes = Console.readInt("Mes: ");
		int dia = Console.readInt("Dia: ");

		LocalDate aniversario = LocalDate.of(ano, mes, dia);

		Console.println(idade(aniversario));
		Console.println("Signo e: "+signo(dia, mes));

	}

	public static int idade(final LocalDate aniversario) {
		final LocalDate dataAtual = LocalDate.now();
		final Period periodo = Period.between(aniversario, dataAtual);
		return periodo.getYears();
	}

	public static String signo(int dia, int mes) {
		String signo = "";
		if (mes == 1 && dia > 19 && mes == 2 && dia < 19)
			signo = "aquarios";
		else if (mes == 2 && dia > 18 || mes == 3 && dia < 21)
			signo = "peixes";
		else if (mes == 3 && dia > 20 || mes == 4 && dia < 20)
			signo = "aries";
		else if (mes == 4 && dia > 19 || mes == 5 && dia < 21)
			signo = "Touro";
		else if (mes == 5 && dia > 20 || mes == 6 && dia < 21)
			signo = "gemios";
		else if (mes == 6 && dia > 20 || mes == 7 && dia < 23)
			signo = "cancer";
		else if (mes == 7 && dia > 22 || mes == 8 && dia < 23)
			signo = "le�o";
		else if (mes == 8 && dia > 22 || mes == 9 && dia < 23)
			signo = "virgem";
		else if (mes == 9 && dia > 22 || mes == 10 && dia < 23)
			signo = "libra";
		else if (mes == 10 && dia > 22 || mes == 11 && dia < 22)
			signo = "escorpi�o";
		else if (mes == 11 && dia > 21 || mes == 12 && dia < 22)
			signo = "sagitario";
		else if (mes == 12 && dia > 21 || mes == 1 && dia < 20)
			signo = "capricornio";
		return signo;
	}
}
