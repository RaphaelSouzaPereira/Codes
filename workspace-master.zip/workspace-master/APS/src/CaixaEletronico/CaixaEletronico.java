package CaixaEletronico;

import com.senac.SimpleJava.Console;

public class CaixaEletronico {
	public void run(){
		ContaBancaria c1 = new ContaBancaria();
		Cliente cliente = new Cliente();
		mostraNaTela(cliente.setNome(Console.readString("Digite o nome do cliente: ")));
		mostraNaTela("sistema do banco...");
		mostraNaTela("Ola "+c1.nome(cliente));
		mostraNaTela("Seu saldo agora: "+ c1.getSaldo());
		double valor = 0;
		c1.deposita(valor = Console.readDouble("Digite um valor para depositar: "));
		mostraNaTela("Seu saldo agora: "+ c1.getSaldo());
		double saca = 0;
		c1.saca(saca = Console.readDouble("Digite um valor para sacar: "));
		mostraNaTela("Seu saldo agora: "+ c1.getSaldo());
		
	}

	private void mostraNaTela(String mens) {
		
	Console.println(mens);
		
		
	}

	
}
