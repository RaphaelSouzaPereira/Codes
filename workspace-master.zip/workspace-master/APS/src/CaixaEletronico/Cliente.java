package CaixaEletronico;

public class Cliente{
	
	private String nome;

	public String getNome() {
		return nome;
	}
	
	public String setNome(String nome){
		return this.nome = nome;
	}
	
}
