package CaixaEletronico;

import com.senac.SimpleJava.Console;

public class ContaBancaria{

	private double saldo;
	private String nome;
	
	double deposita(double valor) {
		return this.saldo = saldo + valor;
	}

	double saca(double valor) {
		if (valor <= this.saldo) {
			return this.saldo = saldo - valor;
		} else {
			Console.println("Saldo Insuficiente!, seu saldo:"+this.saldo);
			deposita(valor = Console.readDouble("Digite um valor para depositar se tiver digite 0 se nao tiver: "));
			Console.println("Caso n�o tenha seu seu saldo e: "+this.saldo);
			saca(valor = Console.readDouble("Digite um valor para sacar: "));
			return this.saldo;
		}
	}

		
	public double getSaldo() {		
		return this.saldo;
	}
	
	public String nome(Cliente cliente){
		return nome = cliente.getNome();
		
	}
}
