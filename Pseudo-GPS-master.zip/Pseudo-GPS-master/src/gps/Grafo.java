package gps;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Grafo {
	public static void main(String[] args) throws IOException {
		Vertice listavertices[] = new Vertice[17];
		int source, destination;
		double pesoTotal;
		lendoArquivoVertice("src\\gps\\vertices.txt", listavertices);
		lendoArquivoArestas("src\\gps\\arestas.txt", listavertices);
		andandoPeloGps(listavertices, 1,13 );
		System.out.println("-----------------------------------------------------");

	}

	public static void andandoPeloGps(Vertice[] vertice, int s, int d) {
		Aresta arestamaisleve = null, arestamaisleve2 = null;
		int contador = 0;
		boolean cheguei = false;
		if(vertice[s].id == d) {
			cheguei = true;
		}
		if (vertice[s].id != d) {
			arestamaisleve = vertice[s].getAresta(contador);
			while (arestamaisleve == null) {
				arestamaisleve = vertice[s].getAresta(contador = contador + 1);
				arestamaisleve2 = vertice[s].getAresta(contador = contador + 1);
			}
			for (int i = 0; i < vertice[s].arestas.length; i++) {
				if (vertice[s].getAresta(i) == null) {
					i++;
				} else {
					if(vertice[s].getAresta(i).aberta == false) {
						i++;
					}else {
						if (arestamaisleve.getPeso() < vertice[s].getAresta(i).getPeso()) {
							arestamaisleve2 = arestamaisleve;
							arestamaisleve = vertice[s].getAresta(i);
							
						}else if(arestamaisleve2.getPeso() > arestamaisleve.getPeso() 
								&& arestamaisleve2.getPeso() < vertice[s].getAresta(i).getPeso()) {
								arestamaisleve2 = vertice[s].getAresta(i);
						}
					}
				}
			}
		}
		if(arestamaisleve != null) {
		System.out.println("Voce andou do ponto " + arestamaisleve.getOrigem().getId() + " para "
				+ arestamaisleve.getDestino().getId());
		vertice[s].getAresta(arestamaisleve.getDestino().getId()).aberta = false;
		vertice[arestamaisleve.getDestino().getId()].getAresta(s).aberta = false;
		}
		for(int i = 0; i < vertice[s].arestas.length; i++) {
			if(vertice[s].getAresta(i) == null) {
				i++;
			}else if(vertice[s].getAresta(i).getDestino().getId() == d) {
				cheguei = true;
			}
		}
		if (cheguei == true) {
			System.out.println("Voce chegou ao seu destino: " + d);
		} else {
			andandoPeloGps(vertice, arestamaisleve.getDestino().getId(), d);
		}
	}

	private static void lendoArquivoArestas(String arquivoArestas, Vertice vertices[]) throws IOException {
		try {
			File arqAresta = new File(arquivoArestas);
			Scanner lendoArestas = new Scanner(arqAresta);
			int id, destino;

			while (lendoArestas.hasNext()) {
				id = lendoArestas.nextInt();
				destino = lendoArestas.nextInt();
				Aresta provAresta = new Aresta(vertices[id], vertices[destino], destino);
				vertices[id].setAresta(provAresta, destino);
				destino = lendoArestas.nextInt();
				provAresta = new Aresta(vertices[id], vertices[destino], destino);
				vertices[id].setAresta(provAresta, destino);
				destino = lendoArestas.nextInt();
				provAresta = new Aresta(vertices[id], vertices[destino], destino);
				vertices[id].setAresta(provAresta, destino);
				destino = lendoArestas.nextInt();
				provAresta = new Aresta(vertices[id], vertices[destino], destino);
				vertices[id].setAresta(provAresta, destino);
				lendoArestas.nextLine();
			}
		} catch (IOException e) {
			System.err.printf("Erro na lista: %s.\n", e.getMessage());
		}
	}

	public static void lendoArquivoVertice(String arquivoVertice, Vertice vertices[]) throws IOException {
		try {
			File arqVertice = new File(arquivoVertice);
			Scanner lendoVertice = new Scanner(arqVertice);
			int id;
			double posicaoX, posicaoY;
			while (lendoVertice.hasNext()) {
				id = lendoVertice.nextInt();
				posicaoX = lendoVertice.nextDouble();
				posicaoY = lendoVertice.nextDouble();
				vertices[id] = new Vertice(id, posicaoX, posicaoY);
				lendoVertice.nextLine();
			}
		} catch (IOException e) {
			System.err.printf("Erro na lista: %s.\n", e.getMessage());
		}
	}

}
