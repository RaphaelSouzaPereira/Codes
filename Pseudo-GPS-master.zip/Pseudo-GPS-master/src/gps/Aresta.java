package gps;

public class Aresta {
	Vertice origem, destino;
	int id;
	boolean aberta = true;
	double peso;
	public Aresta(Vertice origem, Vertice destino, int id) {
			this.origem = origem;
			this.destino = destino;
			this.id = id;
			calculaPeso(this.origem.getPosicaoX(), this.origem.getPosicaoY(), this.destino.posicaoX, this.destino.getPosicaoY());
	}
	public void calculaPeso(double x1, double y1, double x2, double y2) {
		this.peso = Math.sqrt(Math.pow(x2-x1, 2)+Math.pow(y2-y1, 2));
		
	}
	public Vertice getOrigem() {
		return origem;
	}
	public void setOrigem(Vertice origem) {
		this.origem = origem;
	}
	public Vertice getDestino() {
		return destino;
	}
	public void setDestino(Vertice destino) {
		this.destino = destino;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public String toString() {
		return "Sou a aresta "+this.getOrigem()+" que vai para "+this.getDestino().getId(); 
	}
	
}
