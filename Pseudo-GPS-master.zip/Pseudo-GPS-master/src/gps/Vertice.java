package gps;

public class Vertice {
	Aresta[] arestas = new Aresta[17];
	int contador = 0;
	double posicaoX, posicaoY;
	int id;
	public Vertice(int id, double posicaoX, double posicaoY) {
		this.id = id;
		this.posicaoX = posicaoX;
		this.posicaoY = posicaoY;
	}
	public void setAresta(Aresta aresta, int iddestino) {
		this.arestas[iddestino] = aresta;
	}
	public Aresta getAresta(int id) {
		return this.arestas[id];
	}
	public double getPosicaoX() {
		return posicaoX;
	}
	public void setPosicaoX(double posicaoX) {
		this.posicaoX = posicaoX;
	}
	public double getPosicaoY() {
		return posicaoY;
	}
	public void setPosicaoY(double posicaoY) {
		this.posicaoY = posicaoY;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String toString() {
		return this.id+" "+this.posicaoX+" "+this.posicaoY;
	}
	
}
