<!DOCTYPE html>
<html>
    <head>
        <title>Pet Shop</title>
        <meta charset="iso-8859-1">
        <link href="../css/style.css" rel="stylesheet" type="text/css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="../css/styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="../JS/util.js"></script>
        <script src="../JS/clientes.js"></script>
    </head>
    <body>
        <div id="header"> <a href="#" id="logo"><img src="../images/logo.gif" width="310" height="114" alt=""></a>
            <ul class="navigation">
                <li class="active"><a href="../petshop.html">Home</a></li>
                <li><a href="petView.php" title="Pets">Pets</a></li>
                <li><a href="servicoView.php" title="Servicos">Serviços</a></li>
            </ul>
        </div>
        <div id="body">
            <div id="content">
                <main>
                    <h2>Cadastra Cliente</h2>

                    <form id="formularioCliente">
                        <label for="txtnome">Nome:</label>
                        <input type="text" id="txtnome">
                        <br/>
                        <label for="txtrg">Rg:</label>
                        <input type="text" id="txtrg">
                        <br/>
                        <input type="submit" id="btnsalvar" value="Salvar">
                        <input type="reset" value="Cancelar">
                        <br/>
                    </form>
                    <h2>Tabela Clientes</h2>
                    <table id="tabelaCliente">
                    </table>
                </main>
            </div>
            <div class="featured">
                <ul>
                    <li><a href="#"><img src="../images/organic-and-chemical-free.jpg" width="300" height="90" alt=""></a></li>
                    <li><a href="#"><img src="../images/good-food.jpg" width="300" height="90" alt=""></a></li>
                    <li class="last"><a href="#"><img src="../images/pet-grooming.jpg" width="300" height="90" alt=""></a></li>
                </ul>
            </div>
        </div>
        <div id="footer">
            <div id="footnote">
                <div class="section">Copyright &copy; 2012 <a href="#">Company Name</a> All rights reserved | Website Template By <a target="_blank" href="http://www.freewebsitetemplates.com/">freewebsitetemplates.com</a></div>
            </div>
        </div>
    </body>
</html>
