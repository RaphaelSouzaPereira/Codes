<?php

include_once("../MODEL/Cliente.php");
include_once("../DAO/ClienteDAO.php");
include_once("../MODEL/Pet.php");
include_once("../DAO/PetDAO.php");

class PetApi {

    public function listar($request, $response, $args) {
        $dao = new PetDAO;
        $array_pets = $dao->listar();
        $response = $response->withJson($array_pets);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function buscar($request, $response, $args) {
        $id = (int) $args['id'];

        $dao = new PetDAO;
        $pet = $dao->getPet($id);

        $response = $response->withJson($pet);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function inserir($request, $response, $args) {
        $var = $request->getParsedBody();
        $dao = new ClienteDAO;
        $cliente = $dao->getClienteRg($var['rg']);
        $pet = new Pet(null, $var['nome'], $cliente);

        $dao = new PetDAO;
        $pet = $dao->inserePet($pet);

        $response = $response->withJson($pet);
        $response = $response->withHeader('Content-type', 'application/json');
        $response = $response->withStatus(201);
        return $response;
    }

    public function atualizar($request, $response, $args) {
        $id = $args['id'];
        $var = $request->getParsedBody();
        $dao = new ClienteDAO;
        $cliente = $dao->getClienteRg($var['rg']);
        $pet = new Pet($id, $var['nome'], $cliente);
        $dao = new PetDAO;
        $dao->atualizaPet($pet);

        $response = $response->withJson($pet);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function deletar($request, $response, $args) {
        $id = $args['id'];
        $dao = new PetDAO;
        $pet = $dao->getPet($id);
        $dao->excluiPet($pet);

        $response = $response->withJson($pet);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

}

?>