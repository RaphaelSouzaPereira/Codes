<?php

include_once("../MODEL/Servico.php");
include_once("../DAO/ServicoDAO.php");

class ServicoApi {

    public function listar($request, $response, $args) {
        $dao = new ServicoDAO;
        $array_servicos = $dao->listar();

        $response = $response->withJson($array_servicos);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function buscar($request, $response, $args) {
        $id = $args['id'];
        $dao = new ServicoDAO;
        $servico = $dao->getServico($id);

        $response = $response->withJson($servico);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function inserir($request, $response, $args) {
        $var = $request->getParsedBody();
        $servico = new Servico(null, $var['nome'], (float) $var['preco'], $var['descricao']);
        $dao = new ServicoDAO;
        $servico = $dao->insereServico($servico);

        $response = $response->withJson($servico);
        $response = $response->withHeader('Content-type', 'application/json');
        $response = $response->withStatus(201);
        return $response;
    }

    public function atualizar($request, $response, $args) {
        $id = $args['id'];
        $var = $request->getParsedBody();
        $servico = new Servico($id, $var['nome'], $var['preco'], $var['descricao']);
        $dao = new ServicoDAO;
        $dao->atualizaServico($servico);

        $response = $response->withJson($servico);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function deletar($request, $response, $args) {
        $id = $args['id'];
        $dao = new ServicoDAO;
        $servico = $dao->getServico($id);
        $dao->excluiServico($id);

        $response = $response->withJson($servico);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

}

?>