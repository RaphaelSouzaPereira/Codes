<?php

include_once("./MODEL/Cliente.php");
include_once("./DAO/ClienteDAO.php");

class ClienteController {

    public function listar($request, $response, $args) {
        $dao = new ClienteDAO;
        $array_clientes = $dao->listar();

        $response = $response->withJson($array_clientes);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function buscar($request, $response, $args) {
        $id = $args['id'];

        $dao = new ClienteDAO;
        $cliente = $dao->getClienteId($id);

        $response = $response->withJson($cliente);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function inserir($request, $response, $args) {
        $var = $request->getParsedBody();
        $cliente = new Cliente(null, $var['nome'], $var['rg']);
        $dao = new ClienteDAO;
        $cliente = $dao->insereCliente($cliente);

        $response = $response->withJson($cliente);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function atualizar($request, $response, $args) {
        $id = (int) $request->getAttribute('id');
        $var = $request->getParsedBody();
        $cliente = new Cliente($id, $var['nome'], $var['rg']);
        $dao = new ClienteDAO;
        $dao->atualizaCliente($cliente);

        $response = $response->withJson($cliente);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

    public function deletar($request, $response, $args) {
        $id = (int) $request->getAttribute('id');
        $dao = new ClienteDAO;
        $cliente = $dao->getClienteId($id);

        $dao->excluiCliente($id);

        $response = $response->withJson($cliente);
        $response = $response->withHeader('Content-type', 'application/json');
        return $response;
    }

}

?>