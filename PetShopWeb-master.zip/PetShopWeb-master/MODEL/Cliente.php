<?php

class Cliente {

    public $id;
    public $nome;
    public $rg;

    function __construct($id, $nome, $rg) {
        $this->id = $id;
        $this->nome = $nome;
        $this->rg = $rg;
    }

    function getId() {
        return $this->id;
    }

    function setId($id) {
        $this->id = $id;
    }

    function getNome() {
        return $this->nome;
    }

    function setNome($nome) {
        $this->nome = $nome;
    }

    function getRg() {
        return $this->rg;
    }

    function setRg($rg) {
        $this->rg = $rg;
    }

}
