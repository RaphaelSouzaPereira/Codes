<?php

include_once 'Cliente.php';

class Pet {

    public $id;
    public $nome;
    public $cliente;

    function __construct($id = null, $nome = null, $cliente = null) {
        $this->id = $id;
        $this->nome = $nome;
        $this->cliente = $cliente;
    }

    function getId() {
        return $this->id;
    }

    function setId($id) {
        $this->id = $id;
    }

    function getNome() {
        return $this->nome;
    }

    function setNome($nome) {
        $this->nome = $nome;
    }

    function getCliente() {
        return $this->cliente;
    }

    function setCliente($cliente) {
        $this->cliente = $cliente;
    }

}
