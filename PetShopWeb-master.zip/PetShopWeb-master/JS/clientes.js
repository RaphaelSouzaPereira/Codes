//VARIAVEIS
var header = ["nome","rg"];
var idTabela = "tabelaCliente";
var idObj = "id";
var baseURL = "http://localhost/PetShopWebServiceV2";

function limparFormulario() {
    document.querySelector("#txtnome").value = "";
    document.querySelector("#txtrg").value = "";
}

function carregarClientes() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {

            montarTabela(JSON.parse(this.responseText),idTabela,header,idObj);
        }
    };
    xhttp.open("GET", baseURL+"/clientes", true);
    xhttp.send();
}

function enviaFormulario(event){
    event.preventDefault();
    $.ajax({
        url: baseURL+'/clientes',
        type: 'POST',
        data: JSON.stringify( { 
            nome: $("#txtnome").val(),
            rg: $("#txtrg").val(),
        }),
        contentType: 'application/json',
        dataType: 'json',
        success: function () {
            limparFormulario();
            carregarClientes();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    })
}

function deletar(id){
    event.preventDefault();
    $.ajax({
        url: baseURL+'/clientes/'+id,
        type: 'DELETE',
        success: function () {
            carregarClientes();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    })
}

function edit(index){
    $("span[name='text"+index+"']").removeAttr("style").hide();
    $("button[name='edit"+index+"']").removeAttr("style").hide();
    $("input[name='input"+index+"']").show();
    $("button[name='save"+index+"']").show();

}

function editSave(id,index){
    //TODO: IF PARA VALIDAR CAMPOS
    $.ajax({
        url: baseURL+'/clientes/'+id,
        type: 'PUT',
        data: JSON.stringify( { 
            nome: $("#nome"+index).val(),
            rg: $("#rg"+index).val(),
        }),
        contentType: 'application/json',
        dataType: 'json',
        success: function () {
            carregarClientes();
            $("button[name='save"+index+"']").removeAttr("style").hide();
            $("button[name='edit"+index+"']").show();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    });
}

//TODO: ATUALIZAR ALTERANDO OS CAMPOS DA TABELA PARA O INPUT

$(function(){
    carregarClientes();

    $("#btnsalvar").on('click', function(event){
        enviaFormulario(event);
    });

});

