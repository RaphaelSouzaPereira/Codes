function montarTabela(obj,id,header,objID) {
	var objIndex = header.length;
	var tableId = "#"+id;

	//delete all rows
	$(tableId).empty();

    //add header
    $(tableId).append("<tr>");
    for(var i = 0; i < objIndex; i++){
        $(tableId).append("<th>"+header[i]+"</th>");
    } 
    $(tableId).append("</tr>");    
    //add columns  
    $(tableId).append("<tbody>");
    for(var i = 0; i < obj.length;i++){
    	$(tableId+" > tbody").append("<tr name=\"tr"+i+"\">");
    	for(j=0;j<objIndex;j++){
    		$(tableId+" >tbody>tr[name='tr"+i+"'").append("<td><span name=\"text"+i+"\">"+obj[i][header[j]]+"</span><input id=\""+header[j].toLowerCase()+i+"\" type=\"text\" style=\"display: none;\" name=\"input"+i+"\" value=\""+obj[i][header[j]]+"\"></td>");
    	}
    	$(tableId+" >tbody>tr[name='tr"+i+"'").append("<td class=\"td-button\"> <button name=\"edit"+i+"\" onclick=\"edit("+i+")\">Editar</button> <button name=\"save"+i+"\" onclick=\"editSave("+obj[i][objID]+","+i+")\" style=\"display:none;\">Salvar</button><button onclick=\"deletar("+obj[i][objID]+")\">X</button></td>");

    }
}





