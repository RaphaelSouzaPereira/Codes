//VARIAVEIS
var header = ["nome", "descricao", "preco"];
var idTabela = "tabelaServico";
var idObj = "id";
var baseURL = "http://localhost/PetShopWebServiceV2";

function limparFormulario() {
    document.querySelector("#txtnome").value = "";
    document.querySelector("#txtdescricao").value = "";
    document.querySelector("#txtpreco").value = "";
}

function carregarServicos() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            montarTabela(JSON.parse(this.responseText), idTabela, header, idObj);
        }
    };
    xhttp.open("GET", baseURL + "/servicos", true);
    xhttp.send();
}

function enviaFormulario(event) {
    event.preventDefault();
    $.ajax({
        url: baseURL + '/servicos',
        type: 'POST',
        data: JSON.stringify({
            nome: $("#txtnome").val(),
            descricao: $("#txtdescricao").val(),
            preco: $("#txtpreco").val()
        }),
        contentType: 'application/json',
        dataType: 'json',
        success: function () {
            limparFormulario();
            carregarServicos();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    })
}

function deletar(id) {
    event.preventDefault();
    $.ajax({
        url: baseURL + '/servicos/' + id,
        type: 'DELETE',
        success: function () {
            carregarServicos();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    })
}

function edit(index) {
    $("span[name='text" + index + "']").removeAttr("style").hide();
    $("button[name='edit" + index + "']").removeAttr("style").hide();
    $("input[name='input" + index + "']").show();
    $("button[name='save" + index + "']").show();

}

function editSave(id, index) {
    //TODO: IF PARA VALIDAR CAMPOS
    $.ajax({
        url: baseURL + '/servicos/' + id,
        type: 'PUT',
        data: JSON.stringify({
            nome: $("#nome" + index).val(),
            descricao: $("#descricao" + index).val(),
            preco: $("#preco" + index).val()
        }),
        contentType: 'application/json',
        dataType: 'json',
        success: function () {
            carregarServicos();
            $("button[name='save" + index + "']").removeAttr("style").hide();
            $("button[name='edit" + index + "']").show();
        },
        fail: function () {
            alert("Algo deu errado.");
        }
    });
    
                carregarServicos();
            $("button[name='save" + index + "']").removeAttr("style").hide();
            $("button[name='edit" + index + "']").show();
}

//TODO: ATUALIZAR ALTERANDO OS CAMPOS DA TABELA PARA O INPUT

$(function () {
    carregarServicos();

    $("#btnsalvar").on('click', function (event) {
        enviaFormulario(event);
    });

});

