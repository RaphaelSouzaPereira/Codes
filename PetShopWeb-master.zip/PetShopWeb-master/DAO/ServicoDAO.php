<?php

include_once("./MODEL/Servico.php");
include_once("./PDOFactory.php");

class ServicoDAO {

    public function listar() {
        $db = PDOFactory::getConexao();
        $sql = 'SELECT * FROM SERVICO';
        $comando = $db->prepare($sql);
        $comando->execute();
        $servicos = array();
        while ($row = $comando->fetch(PDO::FETCH_OBJ)) {
            $servicos[] = new Servico($row->ID_SERVICO, $row->NOME_SERVICO, $row->PRECO, $row->DESCRICAO);
        }
        return $servicos;
    }

    public function getServico($id) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM SERVICO WHERE ID_SERVICO = :id";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':id' => $id,
        ));
        $dados = $query->fetch(PDO::FETCH_OBJ);
        $Servico = new Servico($dados->ID_SERVICO, $dados->NOME_SERVICO, $dados->PRECO, $dados->DESCRICAO);

        return $Servico;
    }

    public function insereServico(Servico $Servico) {
        $db = PDOFactory::getConexao();
        $sql = "INSERT INTO Servico (NOME_SERVICO, PRECO, DESCRICAO) VALUES (:nome, :preco, :descricao)";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':nome' => $Servico->getNome(),
            ':preco' => $Servico->getPreco(),
            ':descricao' => $Servico->getDescricao()
        ));
    }

    public function excluiServico($id_servico) {
        $db = PDOFactory::getConexao();
        $sql = "DELETE FROM Servico WHERE ID_SERVICO = :id";
        $query = $db->prepare($sql);
        $query->execute(array(':id' => $id_servico));
    }

    public function atualizaServico(Servico $Servico) {
        $db = PDOFactory::getConexao();
        $sql = "UPDATE SERVICO SET NOME_SERVICO = :nome, PRECO = :preco, DESCRICAO = :descricao WHERE ID_SERVICO = :id_servico";
        print_r($Servico);
        $query = $db->prepare($sql);
        $query->execute(array(':nome' => $Servico->getNome()
            , ':preco' => $Servico->getPreco()
            , ':id_servico' => $Servico->getId()
            , ':descricao' => $Servico->getDescricao()));
    }

}
