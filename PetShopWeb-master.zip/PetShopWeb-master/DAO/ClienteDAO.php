<?php

include_once("./MODEL/Cliente.php");
include_once("./MODEL/Pet.php");
include_once("./PDOFactory.php");

class ClienteDAO {

    public function listar() {
        $db = PDOFactory::getConexao();
        $sql = 'SELECT * FROM CLIENTE';
        $comando = $db->prepare($sql);
        $comando->execute();
        $clientes = array();
        while ($row = $comando->fetch(PDO::FETCH_OBJ)) {
            $clientes[] = new Cliente($row->ID, $row->NOME, $row->RG);
        }
        return $clientes;
    }

    public function getCliente($Cliente) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM CLIENTE WHERE RG = :rgCliente";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':rgCliente' => $Cliente->getRg(),
        ));
        $dados = $query->fetch();
        $Cliente = new Cliente($dados['ID'], $dados['NOME'], $dados['RG']);
        return $Cliente;
    }

    public function getClienteRg($Rg) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM CLIENTE WHERE RG = :rgCliente";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':rgCliente' => $Rg,
        ));
        $dados = $query->fetch();
        $Cliente = new Cliente($dados['ID'], $dados['NOME'], $dados['RG']);
        return $Cliente;
    }

    public function getClienteId($id) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM CLIENTE WHERE ID = :idCliente";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':idCliente' => $id,
        ));
        $dados = $query->fetch();
        $Cliente = new Cliente($dados['ID'], $dados['NOME'], $dados['RG']);
        return $Cliente;
    }

    public function insereCliente(Cliente $Cliente) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM CLIENTE
				WHERE RG = :rgCliente";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':rgCliente' => $Cliente->getRg()
        ));
        $dados = $query->fetch();
        if ($dados == false) {
            $sql = "INSERT INTO CLIENTE
					(NOME, RG)
				VALUES
					(:nome, :rg)";
            $query = $db->prepare($sql);
            $query->execute(array(
                ':nome' => $Cliente->getNome(),
                ':rg' => $Cliente->getRg(),
            ));
        }
    }

    public function excluiCliente($id) {
        $db = PDOFactory::getConexao();
        $sql = "DELETE from CLIENTE WHERE ID=:id";
        $query = $db->prepare($sql);
        $query->bindParam(":id", $id);
        $query->execute();
    }

    public function atualizaCliente(Cliente $cliente) {
        $db = PDOFactory::getConexao();
        $sql = "UPDATE CLIENTE SET NOME = :nome, RG = :rg WHERE ID = :id_cliente";
        $query = $db->prepare($sql);
        $query->execute(array(':nome' => $cliente->getNome(), ':rg' => $cliente->getRg(), ':id_cliente' => $cliente->getId()));
    }

    public function buscaTodosPets($rg) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT P.* AS PET FROM CLIENTE C INNER JOIN PET P ON C.RG = P.RG_CLIENTE WHERE C.RG = :rg";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':rg' => $rg
        ));
        $pets = array();
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
            $pets[] = new Pet($row->ID, $row->NOME, $row->RG_CLIENTE);
        }
        return $pets;
    }

}
