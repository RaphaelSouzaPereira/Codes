<?php

include_once("./MODEL/Cliente.php");
include_once("./MODEL/Pet.php");
include_once("./PDOFactory.php");

class PetDAO {

    public function listar() {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM pet";
        $comando = $db->prepare($sql);
        $comando->execute();
        $pets = array();
        while ($row = $comando->fetch(PDO::FETCH_OBJ)) {
            $pets[] = new Pet($row->ID_PET, $row->NOME_PET, $row->RG_CLIENTE);
        }
        return $pets;
    }

    public function getPet($id) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM Pet P INNER JOIN CLIENTE C ON C.RG = P.RG_CLIENTE WHERE P.ID_PET = :idPet";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':idPet' => $id
        ));
        $row = $query->fetch(PDO::FETCH_OBJ);
        $Pet = new Pet($row->ID_PET, $row->NOME_PET, new Cliente($row->ID, $row->NOME, $row->RG)
        );
        return $Pet;
    }

    public function inserePet(Pet $Pet) {
        $db = PDOFactory::getConexao();
        $sql = "SELECT * FROM PET WHERE RG_CLIENTE = :rgCliente AND NOME = :nome";
        $query = $db->prepare($sql);
        $query->execute(array(
            ':rgCliente' => $Pet->getCliente()->getRg(),
            ':nome' => $Pet->getNome()
        ));
        $dados = $query->fetch();
        if ($dados == false) {
            $sql = "INSERT INTO Pet (NOME_PET, RG_CLIENTE) VALUES (:nome, :rg)";
            $query = $db->prepare($sql);
            $query->execute(array(
                ':nome' => $Pet->getNome(),
                ':rg' => $Pet->getCliente()->getRg(),
            ));
        }
    }

    public function excluiPet(Pet $pet) {
        $db = PDOFactory::getConexao();
        $sql = "DELETE FROM Pet WHERE ID_PET = :id";
        $query = $db->prepare($sql);
        $query->execute(array(':id' => $pet->getId()));
    }

    public function atualizaPet(Pet $Pet) {
        $db = PDOFactory::getConexao();
        $sql = "UPDATE Pet SET NOME_PET = :nome, RG_CLIENTE = :rg WHERE ID_PET = :id_pet";
        $query = $db->prepare($sql);
        $query->execute(array(':nome' => $Pet->getNome()
            , ':rg' => $Pet->getCliente()->getRg()
            , ':id_pet' => $Pet->getId()));
    }

}
