<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

include_once("./CONTROLLER/ClienteController.php");
include_once("./CONTROLLER/PetController.php");
include_once("./CONTROLLER/ServicoController.php");
//include_once("./CONTROLLER/VendaController.php");
require './vendor/autoload.php';

$app = new \Slim\App;

$app->group('/clientes', function() {
    $this->get('', 'ClienteController:listar');
    $this->post('', 'ClienteController:inserir');

    $this->get('/{id:[0-9]+}', 'ClienteController:buscar');
    $this->put('/{id:[0-9]+}', 'ClienteController:atualizar');
    $this->delete('/{id:[0-9]+}', 'ClienteController:deletar');
});
$app->group('/pets', function() {
    $this->get('', 'PetController:listar');
    $this->post('', 'PetController:inserir');

    $this->get('/{id:[0-9]+}', 'PetController:buscar');
    $this->put('/{id:[0-9]+}', 'PetController:atualizar');
    $this->delete('/{id:[0-9]+}', 'PetController:deletar');
});
$app->group('/servicos', function() {
    $this->get('', 'ServicoController:listar');
    $this->post('', 'ServicoController:inserir');

    $this->get('/{id:[0-9]+}', 'ServicoController:buscar');
    $this->put('/{id:[0-9]+}', 'ServicoController:atualizar');
    $this->delete('/{id:[0-9]+}', 'ServicoController:deletar');
});
/*$app->group('/vendas', function() {
    $this->get('', 'VendaController:listar');
    $this->post('', 'VendaController:inserir');
    $this->delete('/{id:[0-9]+}', 'VendaController:deletar');
});*/
$app->run();
?>