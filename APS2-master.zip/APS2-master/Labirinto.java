package Mapa;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.senac.SimpleJava.Console;

public class Labirinto {

	public void run() throws FileNotFoundException {

		File texto = new File("image/labirinto.txt");
		String room[] = new String[32];
		String lendo;
		Scanner sc = new Scanner(texto);
		int i = 0;
		lendo = sc.next();

		try {
			LerTexto(sc, lendo, room, i);
		} catch (NoSuchElementException e) {
			Console.println("");
		}
	}

	private void LerTexto(Scanner sc, String lendo, String room[], int i) {
		while (sc.hasNext()) {

			if (lendo.equals("room")) {
				if (i < room.length) {
					i++;
				}
				lendo = sc.next();
				room[i] = ("room " + lendo);
				Console.println(room[i]);
				lendo = sc.next();

			}
			if (lendo.equals("south")) {
				lendo = sc.next();
				Console.println("Porta sul leva para sala " + lendo);
				lendo = sc.next();
			} else if (lendo.equals("north")) {
				lendo = sc.next();
				Console.println("Porta norte leva para sala " + lendo);
				lendo = sc.next();
			} else if (lendo.equals("east")) {
				lendo = sc.next();
				Console.println("Porta leste leva para sala " + lendo);
				lendo = sc.next();
			} else if (lendo.equals("west")) {
				lendo = sc.next();
				Console.println("Porta oeste leva para sala " + lendo);
				lendo = sc.next();
			} else if (lendo.equals("up")) {
				lendo = sc.next();
				Console.println("Escada para subir para sala " + lendo);
				lendo = sc.next();
			} else if (lendo.equals("down")) {
				lendo = sc.next();
				Console.println("Escada para descer para sala " + lendo);
				lendo = sc.next();
			}
		}

	}

}
