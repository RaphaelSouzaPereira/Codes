package Heran�aeException;

public class TravaJvm {
	
	public static void main(String[] args) {
        String[] ss = new String[Integer.MAX_VALUE];
    }
}


