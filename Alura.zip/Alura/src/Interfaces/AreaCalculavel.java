package Interfaces;

interface AreaCalculavel {
	
		double calculaArea();

}
