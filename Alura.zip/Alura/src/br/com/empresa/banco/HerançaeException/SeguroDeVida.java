package br.com.empresa.banco.Heran�aeException;

public class SeguroDeVida implements Tributavel {

	@Override
	public double calculaTributos() {
		
		return 42;
	}

}
