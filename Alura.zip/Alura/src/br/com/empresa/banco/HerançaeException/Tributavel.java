package br.com.empresa.banco.Heran�aeException;

public interface Tributavel {
    double calculaTributos();
}