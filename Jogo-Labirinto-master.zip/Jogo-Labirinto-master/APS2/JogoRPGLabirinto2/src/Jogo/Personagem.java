package Jogo;

public class Personagem {
	int vida = 20;
	int ataque = 2;
	int chance = 75;
	Itens mao1 = new Itens();
	Itens mao2 = new Itens();
	Chave tenhoChave = new Chave();
	
	public Chave getTenhoChave() {
		return tenhoChave;
	}
	public void setTenhoChave(Chave tenhoChave) {
		this.tenhoChave = tenhoChave;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public int getAtaque() {
		return ataque;
	}
	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}
	public int getChance() {
		return chance;
	}
	public void setChance(int chance) {
		this.chance = chance;
	}
	public Itens getMao1() {
		return mao1;
	}
	public void setMao1(Itens mao1) {
		this.mao1 = mao1;
	}
	public Itens getMao2() {
		return mao2;
	}
	public void setMao2(Itens mao2) {
		this.mao2 = mao2;
	}
	
	
	
}
