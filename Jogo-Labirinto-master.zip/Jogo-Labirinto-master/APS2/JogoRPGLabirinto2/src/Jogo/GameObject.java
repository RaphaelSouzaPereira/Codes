package Jogo;

import java.io.IOException;

import com.senac.SimpleJava.Graphics.Drawable;
import com.senac.SimpleJava.Graphics.Image;
import com.senac.SimpleJava.Graphics.Point;
import com.senac.SimpleJava.Graphics.Sprite;

public class GameObject extends Sprite implements Drawable  {

	public GameObject(Image img) throws IOException {
		super(img);
		
	}

	public boolean clicked(Point p) {
		int objX = this.getBounds().x;
		int objY = this.getBounds().y;
		int objHeight = this.getHeight();
		int objWidth = this.getWidth();
		
		if (p.x >= objX && p.y >= objY && p.x <= objX+objHeight && p.y <= objY+objWidth) {
			return true;
		}
		return false;
	}


	

}
