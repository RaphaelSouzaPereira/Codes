package Jogo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.senac.SimpleJava.Console;
import com.senac.SimpleJava.Graphics.Canvas;
import com.senac.SimpleJava.Graphics.GraphicApplication;
import com.senac.SimpleJava.Graphics.Image;
import com.senac.SimpleJava.Graphics.Point;
import com.senac.SimpleJava.Graphics.Resolution;
import com.senac.SimpleJava.Graphics.events.MouseEvent;
import com.senac.SimpleJava.Graphics.events.MouseObserver;

import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

public class RPG extends GraphicApplication implements MouseObserver {

	private Resolution res;
	private Image bg;
	private Random random = new Random();
	private GameObject portanorte, portasul, portaleste, portaoeste, escadasobe, escadadesce, guerreiro;
	private Sala[] salas = new Sala[32];
	public int salaatual = random.nextInt(32);
	private Image portaSUL, portaNORTE, portaLESTE, portaOESTE, escadaSOBE, escadaDESCE, botao;
	private Image goblin, orc, troll;
	private Image espada, faca, adaga, espadalarga;
	private Image armaduracouro, armadurametal, armaduramithril, escudo, chave;
	private Personagem heroi = new Personagem();
	private static final String SCENARIO_IMAGE = "image/Scenario.JPG";
	private static final String CHAVECINZA = "image/chavecinza.jpg";
	private static final String CHAVEAZUL = "image/chaveazul.jpg";
	private static final String CHAVEVERDE = "image/chaveverde.jpg";
	private static final String CHAVEVERMELHA = "image/chavevermelha.jpg";
	private static final String PORTABAIXO = "image/PortaBaixo.jpg";
	private static final String PORTACIMA = "image/PortaCima.jpg";
	private static final String PORTADIREITA = "image/PortaDireita.jpg";
	private static final String PORTAESQUERDA = "image/PortaEsquerda.jpg";
	private static final String PORTABAIXOVERMELHA = "image/PortaBaixoVermelha.jpg";
	private static final String PORTACIMAVERMELHA = "image/PortaCimaVermelha.jpg";
	private static final String PORTADIREITAVERMELHA = "image/PortaDireitaVermelha.jpg";
	private static final String PORTAESQUERDAVERMELHA = "image/PortaEsquerdaVermelha.jpg";
	private static final String ESCADASOBE = "image/escadasobe.jpg";
	private static final String ESCADADESCE = "image/escadadesce.jpg";
	private static final String PAREDECIMA = "image/ParedeCima.jpg";
	private static final String PAREDEBAIXO = "image/ParedeBaixo.jpg";
	private static final String PAREDEDIREITA = "image/ParedeDireita.jpg";
	private static final String PAREDEESQUERDA = "image/ParedeEsquerda.jpg";
	private static final String CHAO = "image/ChaoEscada.jpg";
	private static final String ADAGA = "image/adaga.jpg";
	private static final String ARMADURACOURO = "image/armaduracouro.jpg";
	private static final String ARMADURAMETAL = "image/armadurametal.jpg";
	private static final String ARMADURAMITHRIL = "image/armaduramithril.jpg";
	private static final String PERSONAGEM = "image/personagem.jpg";
	private static final String ESCUDO = "image/escudo.jpg";
	private static final String ESPADALONGA = "image/espadalonga.jpg";
	private static final String ESPADA = "image/espada.jpg";
	private static final String FACA = "image/faca.jpg";
	private static final String GOBLIN = "image/goblin.jpg";
	private static final String ORC = "image/orc.png";
	private static final String TROLL = "image/troll.jpg";
	private static final String PORTACIMAAZUL = "image/PortaCimaAzul.jpg";
	private static final String PORTACIMAVERDE = "image/PortaCimaVerde.jpg";
	private static final String PORTABAIXOAZUL = "image/PortaBaixoAzul.jpg";
	private static final String PORTABAIXOVERDE = "image/PortaBaixoVerde.jpg";
	private static final String PORTADIREITAAZUL = "image/PortaDireitaAzul.jpg";
	private static final String PORTADIREITAVERDE = "image/PortaDireitaVerde.jpg";
	private static final String PORTAESQUERDAAZUL = "image/PortaEsquerdaAzul.jpg";
	private static final String PORTAESQUERDAVERDE = "image/PortaEsquerdaVerde.jpg";
	private static final String BOTAO = "image/botao.jpg";

	@Override
	protected void draw(Canvas canvas) {
		canvas.clear();
		try {
			if (heroi.getVida() > 0) {
				if (salaatual > 0) {

					canvas.drawImage(bg, 0, 0);
					canvas.putText(590, 100, 20, "RPG Labirinto");
					canvas.putText(2, 570, 20, String.format("Life remains: " + heroi.getVida()));
					canvas.putText(590, 125, 20, String.format("Room: " + salaatual));
					guerreiro.draw(canvas);
					portanorte.draw(canvas);
					portasul.draw(canvas);
					portaleste.draw(canvas);
					portaoeste.draw(canvas);
					escadasobe.draw(canvas);
					escadadesce.draw(canvas);

					if (salas[salaatual].verificaporta(0) == true) {
						canvas.drawImage(portaSUL, 357, 510);
						if (salas[salaatual].portas[0].isExistearmadilha() == true) {
							botao = new Image(BOTAO);
							canvas.drawImage(botao, 310, 520);
						}
						if (salas[salaatual].verificamonstro(0) == true) {
							if (salas[salaatual].monstros[0].getTipo() == 0) {
								goblin = new Image(GOBLIN);
								canvas.drawImage(goblin, 357, 510);
							} else if (salas[salaatual].monstros[0].getTipo() == 1) {
								orc = new Image(ORC);
								canvas.drawImage(orc, 357, 510);
							} else if (salas[salaatual].monstros[0].getTipo() == 2) {
								troll = new Image(TROLL);
								canvas.drawImage(troll, 357, 510);
							}
						}
					}

					if (salas[salaatual].verificaporta(1) == true) {
						canvas.drawImage(portaNORTE, 335, 30);
						if (salas[salaatual].portas[1].isExistearmadilha() == true) {
							botao = new Image(BOTAO);
							canvas.drawImage(botao, 310, 70);
						}
						if (salas[salaatual].verificamonstro(1) == true) {
							if (salas[salaatual].monstros[1].getTipo() == 0) {
								goblin = new Image(GOBLIN);
								canvas.drawImage(goblin, 335, 30);
							} else if (salas[salaatual].monstros[1].getTipo() == 1) {
								orc = new Image(ORC);
								canvas.drawImage(orc, 335, 30);
							} else if (salas[salaatual].monstros[1].getTipo() == 2) {
								troll = new Image(TROLL);
								canvas.drawImage(troll, 335, 30);
							}
						}

					}

					if (salas[salaatual].verificaporta(2) == true) {
						canvas.drawImage(portaLESTE, 725, 260);
						if (salas[salaatual].portas[2].isExistearmadilha() == true) {
							botao = new Image(BOTAO);
							canvas.drawImage(botao, 735, 220);
						}
						if (salas[salaatual].verificamonstro(2) == true) {
							if (salas[salaatual].monstros[2].getTipo() == 0) {
								goblin = new Image(GOBLIN);
								canvas.drawImage(goblin, 725, 260);
							} else if (salas[salaatual].monstros[2].getTipo() == 1) {
								orc = new Image(ORC);
								canvas.drawImage(orc, 725, 260);
							} else if (salas[salaatual].monstros[2].getTipo() == 2) {
								troll = new Image(TROLL);
								canvas.drawImage(troll, 725, 260);
							}
						}
					}

					if (salas[salaatual].verificaporta(3) == true) {
						canvas.drawImage(portaOESTE, 2, 235);
						if (salas[salaatual].portas[3].isExistearmadilha() == true) {
							botao = new Image(BOTAO);
							canvas.drawImage(botao, 25, 200);
						}
						if (salas[salaatual].verificamonstro(3) == true) {
							if (salas[salaatual].monstros[3].getTipo() == 0) {
								goblin = new Image(GOBLIN);
								canvas.drawImage(goblin, 2, 235);
							} else if (salas[salaatual].monstros[3].getTipo() == 1) {
								orc = new Image(ORC);
								canvas.drawImage(orc, 2, 235);
							} else if (salas[salaatual].monstros[3].getTipo() == 2) {
								troll = new Image(TROLL);
								canvas.drawImage(troll, 2, 235);
							}
						}
					}

					if (salas[salaatual].verificaporta(4) == true) {
						canvas.drawImage(escadaSOBE, 83, 83);
					}

					if (salas[salaatual].verificaporta(5) == true) {
						canvas.drawImage(escadaDESCE, 160, 91);
					}

					if (salas[salaatual].verificachave() == true) {
						if (salas[salaatual].chave.getNumero() == 1) {
							chave = new Image(CHAVECINZA);
							canvas.drawImage(chave, 300, 250);
						}
						if (salas[salaatual].chave.getNumero() == 2) {
							chave = new Image(CHAVEVERMELHA);
							canvas.drawImage(chave, 300, 250);
						}
						if (salas[salaatual].chave.getNumero() == 3) {
							chave = new Image(CHAVEAZUL);
							canvas.drawImage(chave, 300, 250);
						}
						if (salas[salaatual].chave.getNumero() == 4) {
							chave = new Image(CHAVEVERDE);
							canvas.drawImage(chave, 300, 250);
						}
					}

					if (salas[salaatual].verificaitens() == true) {
						if (salas[salaatual].equipamentos.getNumero() == 1) {
							adaga = new Image(ADAGA);
							canvas.drawImage(adaga, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 2) {
							faca = new Image(FACA);
							canvas.drawImage(faca, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 3) {
							espada = new Image(ESPADA);
							canvas.drawImage(espada, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 4) {
							espadalarga = new Image(ESPADALONGA);
							canvas.drawImage(espadalarga, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 5) {
							escudo = new Image(ESCUDO);
							canvas.drawImage(escudo, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 6) {
							armaduracouro = new Image(ARMADURACOURO);
							canvas.drawImage(armaduracouro, 500, 250);
						}
						if (salas[salaatual].equipamentos.getNumero() == 7) {
							armadurametal = new Image(ARMADURAMETAL);
							canvas.drawImage(armadurametal, 500, 250);

						}
						if (salas[salaatual].equipamentos.getNumero() == 8) {
							armaduramithril = new Image(ARMADURAMITHRIL);
							canvas.drawImage(armaduramithril, 500, 250);
						}
					}

					// canvas.drawLine(x0, y0, x1, y1);

				}
				if (salaatual == 0) {
					Console.println("FIM DO JOGO");
					canvas.putText(250, 400, 35, String.format("Voc� saiu do labirinto"));
				}

			} else {
				Console.println("FIM DO JOGO VOC� MORREU");
				canvas.putText(res.height, res.width, 60, String.format("VOC� MORREU LIXO! HEHEHE"));
			}
		} catch (NullPointerException e) {
			Console.println("Terminou mesmo!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void loop() {

	}

	@Override
	protected void setup() {
		salas[0] = new Sala(0);
		addMouseObserver(MouseEvent.CLICK, this);
		Resolution res = Resolution.HIGHRES;
		setFramesPerSecond(60);
		setResolution(res);

		try {
			// Background

			bg = new Image(SCENARIO_IMAGE);
			bg.resize(res.width, res.height);
			guerreiro = criaPadrao(res, 400, 250, PERSONAGEM);
			portasul = criaPadrao(res, 357.0, 510.0, PAREDEBAIXO);
			portanorte = criaPadrao(res, 335.0, 30.0, PAREDECIMA);
			portaleste = criaPadrao(res, 725.0, 260.0, PAREDEDIREITA);
			portaoeste = criaPadrao(res, 2.0, 235.0, PAREDEESQUERDA);
			escadasobe = criaPadrao(res, 83.0, 83.0, CHAO);
			escadadesce = criaPadrao(res, 160.0, 91.0, CHAO);

		} catch (IOException e) {
			Console.println("");
		}
		try {
			File texto = new File("image/labirinto.txt");
			String lendo, direcao = "";
			Scanner sc = new Scanner(texto);
			int contasalas = 0;
			int proximasala = 0;
			lendo = sc.next();
			LerTexto(proximasala, sc, lendo, direcao, salas, contasalas);

		} catch (FileNotFoundException e1) {
			Console.println("N�o tem Arquivo");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			Console.println("");

		}

	}

	private void LerTexto(int proximasala, Scanner sc, String lendo, String direcao, Sala[] salas2,
			int contasalas) throws IOException {
		
		while (sc.hasNext()) {
			int sorteio = 0;
			if (lendo.equals("room")) {
				lendo = sc.next();
				contasalas = Integer.parseInt(lendo);
				if (contasalas <= 32) {
					salas[contasalas] = new Sala(contasalas);
					salas[contasalas].criaChaves();
					salas[contasalas].criaItem();
					lendo = sc.next();
				}
			}
			if (lendo.equals("south")) {
				direcao = lendo;
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				sorteio = random.nextInt(5);
				while (sorteio == 0) {
					sorteio = random.nextInt(5);
				}
				if (sorteio == 1) {
					salas[contasalas].setI(direcao, proximasala);
					portaSUL = new Image(PORTABAIXO);
					salas[contasalas].portas[0].setPorta(portaSUL);
					salas[contasalas].portas[0].setNumero(1);
				}
				if (sorteio == 2) {
					salas[contasalas].setI(direcao, proximasala);
					portaSUL = new Image(PORTABAIXOVERMELHA);
					salas[contasalas].portas[0].setPorta(portaSUL);
					salas[contasalas].portas[0].setNumero(2);
				}
				if (sorteio == 3) {
					salas[contasalas].setI(direcao, proximasala);
					portaSUL = new Image(PORTABAIXOAZUL);
					salas[contasalas].portas[0].setPorta(portaSUL);
					salas[contasalas].portas[0].setNumero(3);
				}
				if (sorteio == 4) {
					salas[contasalas].setI(direcao, proximasala);
					portaSUL = new Image(PORTABAIXOVERDE);
					salas[contasalas].portas[0].setPorta(portaSUL);
					salas[contasalas].portas[0].setNumero(4);
				}
				lendo = sc.next();
			}if (lendo.equals("north")) {
				direcao = lendo;
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				sorteio = random.nextInt(5);
				while (sorteio == 0) {
					sorteio = random.nextInt(5);
				}
				if (sorteio == 1) {
					salas[contasalas].setI(direcao, proximasala);
					portaNORTE = new Image(PORTACIMA);
					salas[contasalas].portas[1].setPorta(portaNORTE);
					salas[contasalas].portas[1].setNumero(1);
				}
				if (sorteio == 2) {
					salas[contasalas].setI(direcao, proximasala);
					portaNORTE = new Image(PORTACIMAVERMELHA);
					salas[contasalas].portas[1].setPorta(portaNORTE);
					salas[contasalas].portas[1].setNumero(2);
				}
				if (sorteio == 3) {
					salas[contasalas].setI(direcao, proximasala);
					portaNORTE = new Image(PORTACIMAAZUL);
					salas[contasalas].portas[1].setPorta(portaNORTE);
					salas[contasalas].portas[1].setNumero(3);
				}
				if (sorteio == 4) {
					salas[contasalas].setI(direcao, proximasala);
					portaNORTE = new Image(PORTACIMAVERDE);
					salas[contasalas].portas[1].setPorta(portaNORTE);
					salas[contasalas].portas[1].setNumero(4);
				}
				lendo = sc.next();
			}if (lendo.equals("east")) {
				direcao = lendo;
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				sorteio = random.nextInt(5);
				while (sorteio == 0) {
					sorteio = random.nextInt(5);
				}
				
				if (sorteio == 1) {
					salas[contasalas].setI(direcao, proximasala);
					portaLESTE = new Image(PORTADIREITA);
					salas[contasalas].portas[2].setPorta(portaLESTE);
					salas[contasalas].portas[2].setNumero(1);
				}
				if (sorteio == 2) {
					salas[contasalas].setI(direcao, proximasala);
					portaLESTE = new Image(PORTADIREITAVERMELHA);
					salas[contasalas].portas[2].setPorta(portaLESTE);
					salas[contasalas].portas[2].setNumero(2);
				}
				if (sorteio == 3) {
					salas[contasalas].setI(direcao, proximasala);
					portaLESTE = new Image(PORTADIREITAAZUL);
					salas[contasalas].portas[2].setPorta(portaLESTE);
					salas[contasalas].portas[2].setNumero(3);
				}
				if (sorteio == 4) {
					salas[contasalas].setI(direcao, proximasala);
					portaLESTE = new Image(PORTADIREITAVERDE);
					salas[contasalas].portas[2].setPorta(portaLESTE);
					salas[contasalas].portas[2].setNumero(4);
				}
				lendo = sc.next();
			}if (lendo.equals("west")) {
				direcao = lendo;
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				sorteio = random.nextInt(5);
				while (sorteio == 0) {
					sorteio = random.nextInt(5);
				}
			
				if (sorteio == 1) {
					salas[contasalas].setI(direcao, proximasala);
					portaOESTE = new Image(PORTAESQUERDA);
					salas[contasalas].portas[3].setPorta(portaOESTE);
					salas[contasalas].portas[3].setNumero(1);
				}
				if (sorteio == 2) {
					salas[contasalas].setI(direcao, proximasala);
					portaOESTE = new Image(PORTAESQUERDAVERMELHA);
					salas[contasalas].portas[3].setPorta(portaOESTE);
					salas[contasalas].portas[3].setNumero(2);
				}
				if (sorteio == 3) {
					salas[contasalas].setI(direcao, proximasala);
					portaOESTE = new Image(PORTAESQUERDAAZUL);
					salas[contasalas].portas[3].setPorta(portaOESTE);
					salas[contasalas].portas[3].setNumero(3);
				}
				if (sorteio == 4) {
					salas[contasalas].setI(direcao, proximasala);
					portaOESTE = new Image(PORTAESQUERDAVERDE);
					salas[contasalas].portas[3].setPorta(portaOESTE);
					salas[contasalas].portas[3].setNumero(4);
				}
				lendo = sc.next();
			} else if (lendo.equals("up")) {
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				salas[contasalas].setEscadaSobe(proximasala);
				escadaSOBE = new Image(ESCADASOBE);
				salas[contasalas].portas[4].setPorta(escadaSOBE);
				lendo = sc.next();
			} else if (lendo.equals("down")) {
				lendo = sc.next();
				proximasala = Integer.parseInt(lendo);
				salas[contasalas].setEscadaDesce(proximasala);
				escadaDESCE = new Image(ESCADADESCE);
				salas[contasalas].portas[5].setPorta(escadaDESCE);
				lendo = sc.next();
			}

		}

	}

	private GameObject criaPadrao(Resolution res, double largura, double altura, String objeto) throws IOException {
		Image img = new Image(objeto);
		GameObject porta = new GameObject(img);
		porta.setPosition(new Point(largura, altura));
		return porta;
	}

	@Override
	public void notify(MouseEvent clique, int a, Point p) {
		if (clique == MouseEvent.CLICK) {

			if (salas[salaatual].verificaitens() == true && p.x >= 500 && p.x <= 530 && p.y >= 250 && p.y <= 280) {
				if (salas[salaatual].equipamentos.getNumero() < 5) {
					heroi.setMao1(salas[salaatual].equipamentos);
					if (heroi.mao1.getNumero() == 1) {
						Console.println("Voc� est� com a adaga");
					}
					if (heroi.mao1.getNumero() == 2) {
						Console.println("Voc� est� com a faca");
					}
					if (heroi.mao1.getNumero() == 3) {
						Console.println("Voc� est� com a espada");
					}
					if (heroi.mao1.getNumero() == 4) {
						Console.println("Voc� est� com a ESPADA LARGA!!!!");
					}
				} else {
					heroi.setMao2(salas[salaatual].equipamentos);
					if (heroi.mao2.getNumero() == 5) {
						Console.println("Voc� est� com o escudo");
					}
					if (heroi.mao2.getNumero() == 6) {
						Console.println("Voc� est� com a armadura de couro");
					}
					if (heroi.mao2.getNumero() == 7) {
						Console.println("Voc� est� com a armadura de metal");
					}
					if (heroi.mao2.getNumero() == 8) {
						Console.println("Voc� est� com a armadura de MITHRIL!!!!");
					}
				}
			}

			if (salas[salaatual].verificachave() == true && p.x >= 300 && p.x <= 330 && p.y >= 250 && p.y <= 280) {
				heroi.setTenhoChave(salas[salaatual].chave);
				if (heroi.tenhoChave.getNumero() == 1) {
					Console.println(heroi.tenhoChave.getNumero());
					heroi.tenhoChave.setExiste(true);
					heroi.tenhoChave.setNumero(1);
					Console.println("Tenho chave cinza");
				}
				if (heroi.tenhoChave.getNumero() == 2) {
					Console.println(heroi.tenhoChave.getNumero());
					heroi.tenhoChave.setExiste(true);
					heroi.tenhoChave.setNumero(2);
					Console.println("Tenho chave vermelha");
				}
				if (heroi.tenhoChave.getNumero() == 3) {
					Console.println(heroi.tenhoChave.getNumero());
					heroi.tenhoChave.setExiste(true);
					heroi.tenhoChave.setNumero(3);
					Console.println("Tenho chave azul");
				}
				if (heroi.tenhoChave.getNumero() == 4) {
					Console.println(heroi.tenhoChave.getNumero());
					heroi.tenhoChave.setExiste(true);
					heroi.tenhoChave.setNumero(4);
					Console.println("Tenho chave verde");
				}
			}

			if (salas[salaatual].verificamonstro(0) == false && salas[salaatual].verificaporta(0) == true && p.x >= 357
					&& p.x <= 470 && p.y >= 510 && p.y <= 560) {
				if (salas[salaatual].portas[0].isExistearmadilha() == true) {
					heroi.setVida(0);
				}
				if (salas[salaatual].portas[0].isExistearmadilha() == false) {
					if (salas[salaatual].portas[0].isExistetranca() == true
							&& salas[salaatual].portas[0].getNumero() == 1) {
						if (heroi.tenhoChave.getNumero() == 1) {
							salas[salaatual].portas[0].setExistetranca(false);
							Console.println("Porta destrancada.");
						} else {
							Console.println(salas[salaatual].portas[0].getNumero());
							Console.println("Sala Trancada e voc� n�o tem a chave certa.");
						}

					}
					else if (salas[salaatual].portas[0].isExistetranca() == true
							&& salas[salaatual].portas[0].getNumero() == 2) {
						if (heroi.tenhoChave.getNumero() == 2) {
							salas[salaatual].portas[0].setExistetranca(false);
							Console.println("Porta destrancada.");
						} else {
							Console.println(salas[salaatual].portas[0].getNumero());
							Console.println("Sala Trancada e voc� n�o tem a chave certa.");
						}

					}
					else if (salas[salaatual].portas[0].isExistetranca() == true
							&& salas[salaatual].portas[0].getNumero() == 3) {
						if (heroi.tenhoChave.getNumero() == 3) {
							salas[salaatual].portas[0].setExistetranca(false);
							Console.println("Porta destrancada.");
						} else {
							Console.println(salas[salaatual].portas[0].getNumero());
							Console.println("Sala Trancada e voc� n�o tem a chave certa.");
						}

					}
					else if (salas[salaatual].portas[0].isExistetranca() == true
							&& salas[salaatual].portas[0].getNumero() == 4) {
						if (heroi.tenhoChave.getNumero() == 4) {
							salas[salaatual].portas[0].setExistetranca(false);
							Console.println("Porta destrancada.");
						} else {
							Console.println(salas[salaatual].portas[0].getNumero());
							Console.println("Sala Trancada e voc� n�o tem a chave certa.");
						}

					}
					if (salas[salaatual].portas[0].isExistetranca() == false) {
						salaatual = salas[salaatual].portas[0].proximasala;
					}
				}
			}

			if (salas[salaatual].verificamonstro(0) == true && p.x >= 357 && p.x <= 470 && p.y >= 510 && p.y <= 560) {
				luta(0);
			}

			if (salas[salaatual].verificamonstro(1) == false && salas[salaatual].verificaporta(1) == true && p.x >= 335
					&& p.x <= 448 && p.y >= 30 && p.y <= 80) {
				if (salas[salaatual].portas[1].isExistearmadilha() == true) {
					heroi.setVida(0);
				}else if (salas[salaatual].portas[1].isExistearmadilha() == false) {
				if (salas[salaatual].portas[1].isExistetranca() == true
						&& salas[salaatual].portas[1].getNumero() == 1) {
					if (heroi.tenhoChave.getNumero() == 1) {
						Console.println("Porta destrancada.");
						salas[salaatual].portas[1].setExistetranca(false);
					} else {
						Console.println(salas[salaatual].portas[1].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[1].isExistetranca() == true
						&& salas[salaatual].portas[1].getNumero() == 2) {
					if (heroi.tenhoChave.getNumero() == 2) {
						salas[salaatual].portas[1].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[1].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[1].isExistetranca() == true
						&& salas[salaatual].portas[1].getNumero() == 3) {
					if (heroi.tenhoChave.getNumero() == 3) {
						salas[salaatual].portas[1].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[1].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[1].isExistetranca() == true
						&& salas[salaatual].portas[1].getNumero() == 4) {
					if (heroi.tenhoChave.getNumero() == 4) {
						salas[salaatual].portas[1].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[1].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				if(salas[salaatual].portas[1].isExistetranca() == false){
					salaatual = salas[salaatual].portas[1].proximasala;
				}
			}
			}
			if (salas[salaatual].verificamonstro(1) == true && p.x >= 335 && p.x <= 448 && p.y >= 30 && p.y <= 80) {
				luta(1);
			}

			if (salas[salaatual].verificamonstro(2) == false && salas[salaatual].verificaporta(2) == true && p.x >= 725
					&& p.x <= 775 && p.y >= 260 && p.y <= 380) {
				if (salas[salaatual].portas[2].isExistearmadilha() == true) {
					heroi.setVida(0);
				}else if (salas[salaatual].portas[2].isExistearmadilha() == false) {
				if (salas[salaatual].portas[2].isExistetranca() == true
						&& salas[salaatual].portas[2].getNumero() == 1) {
					if (heroi.tenhoChave.getNumero() == 1) {
						salas[salaatual].portas[2].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[2].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[2].isExistetranca() == true
						&& salas[salaatual].portas[2].getNumero() == 2) {
					if (heroi.tenhoChave.getNumero() == 2) {
						salas[salaatual].portas[2].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[2].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[2].isExistetranca() == true
						&& salas[salaatual].portas[2].getNumero() == 3) {
					if (heroi.tenhoChave.getNumero() == 3) {
						salas[salaatual].portas[2].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[2].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[2].isExistetranca() == true
						&& salas[salaatual].portas[2].getNumero() == 4) {
					if (heroi.tenhoChave.getNumero() == 4) {
						salas[salaatual].portas[2].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[2].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				if(salas[salaatual].portas[2].isExistetranca() == false){
					salaatual = salas[salaatual].portas[2].proximasala;
				}
			}
			}

			if (salas[salaatual].verificamonstro(2) == true && p.x >= 725 && p.x <= 775 && p.y >= 260 && p.y <= 380) {
				luta(2);
			}

			if (salas[salaatual].verificamonstro(3) == false && salas[salaatual].verificaporta(3) == true && p.x >= 2
					&& p.x <= 52 && p.y >= 235 && p.y <= 355) {
				if (salas[salaatual].portas[3].isExistearmadilha() == true) {
					heroi.setVida(0);
				}else if (salas[salaatual].portas[3].isExistearmadilha() == false) {
				if (salas[salaatual].portas[3].isExistetranca() == true
						&& salas[salaatual].portas[3].getNumero() == 1) {
					if (heroi.tenhoChave.getNumero() == 1) {
						salas[salaatual].portas[3].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[3].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[3].isExistetranca() == true
						&& salas[salaatual].portas[3].getNumero() == 2) {
					if (heroi.tenhoChave.getNumero() == 2) {
						salas[salaatual].portas[3].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[3].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[3].isExistetranca() == true
						&& salas[salaatual].portas[3].getNumero() == 3) {
					if (heroi.tenhoChave.getNumero() == 3) {
						salas[salaatual].portas[3].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[3].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				else if (salas[salaatual].portas[3].isExistetranca() == true
						&& salas[salaatual].portas[3].getNumero() == 4) {
					if (heroi.tenhoChave.getNumero() == 4) {
						salas[salaatual].portas[3].setExistetranca(false);
						Console.println("Porta destrancada.");
					} else {
						Console.println(salas[salaatual].portas[3].getNumero());
						Console.println("Sala Trancada e voc� n�o tem a chave certa.");
					}

				}
				if(salas[salaatual].portas[3].isExistetranca() == false){
					salaatual = salas[salaatual].portas[3].proximasala;
				}
				}
			}

			if (salas[salaatual].verificamonstro(3) == true && p.x >= 2 && p.x <= 52 && p.y >= 235 && p.y <= 355) {
				luta(3);
			}

			if (salas[salaatual].verificaporta(4) == true && p.x >= 83 && p.x <= 103 && p.y >= 83 && p.y <= 110) {
				salaatual = salas[salaatual].portas[4].proximasala;

			}
			if (salas[salaatual].verificaporta(5) == true && p.x >= 160 && p.x <= 180 && p.y >= 91 && p.y <= 120) {
				salaatual = salas[salaatual].portas[5].proximasala;
			}

			if (p.x >= 310 && p.x <= 330 && p.y >= 520 && p.y <= 540) {
				salas[salaatual].portas[0].setExistearmadilha(false);
			}
			if (p.x >= 310 && p.x <= 330 && p.y >= 70 && p.y <= 90) {
				salas[salaatual].portas[1].setExistearmadilha(false);
			}
			if (p.x >= 735 && p.x <= 755 && p.y >= 220 && p.y <= 240) {
				salas[salaatual].portas[2].setExistearmadilha(false);
			}
			if (p.x >= 25 && p.x <= 45 && p.y >= 200 && p.y <= 220) {
				salas[salaatual].portas[3].setExistearmadilha(false);
			}

		}

		redraw();
	}

	private void luta(int i) {
		int chancedoataque = random.nextInt(101);
		if (heroi.mao1.isExiste() == true) {
			if (chancedoataque <= heroi.mao1.getChanceArma()) {
				salas[salaatual].monstros[i].setVida(
						salas[salaatual].monstros[i].getVida() - (heroi.getAtaque() + heroi.mao1.getDanoArma()));
				Console.println("Voc� acertou. ");
				if (salas[salaatual].monstros[i].getVida() > 0) {
					chancedoataque = random.nextInt(101);
					if (heroi.mao2 != null && heroi.mao2.getNumero() == 5) {
						if (chancedoataque <= (salas[salaatual].monstros[i].getChance()
								- heroi.mao2.getChanceDefesa())) {
							heroi.setVida(heroi.getVida() - salas[salaatual].monstros[i].getDano());
							Console.println("Monstro acertou.");
						} else if (chancedoataque > (salas[salaatual].monstros[i].getChance()
								- heroi.mao2.getChanceDefesa())) {
							Console.println("Monstro errou.");
						}
					} else if (heroi.mao2 != null && heroi.mao2.getNumero() != 5) {
						if (chancedoataque <= salas[salaatual].monstros[i].getChance()) {
							if (salas[salaatual].monstros[i].getDano() - heroi.mao2.getDefesaArmaduras() > 0) {
								heroi.setVida(heroi.getVida()
										- (salas[salaatual].monstros[i].getDano() - heroi.mao2.getDefesaArmaduras()));
								Console.println("Monstro acertou.");
							}
						} else if (chancedoataque > salas[salaatual].monstros[i].getChance()) {
							Console.println("Monstro errou.");
						}
					} else if (chancedoataque <= salas[salaatual].monstros[i].getChance()) {
						heroi.setVida(heroi.getVida() - salas[salaatual].monstros[i].getDano());
					} else if (chancedoataque > salas[salaatual].monstros[i].getChance()) {
						Console.println("Monstro errou.");
					}
				} else {
					salas[salaatual].monstros[i].setExisteInimigo(false);
				}
			} else {
				Console.println("Voc� errou.");
			}
		}
		if (heroi.mao1.isExiste() == false) {
			chancedoataque = random.nextInt(101);
			if (chancedoataque <= heroi.getChance()) {
				salas[salaatual].monstros[i].setVida(salas[salaatual].monstros[i].getVida() - heroi.getAtaque());
				Console.println("Voc� acertou. ");
				if (salas[salaatual].monstros[i].getVida() > 0) {
					chancedoataque = random.nextInt(101);
					if (heroi.mao2 != null && heroi.mao2.getNumero() == 5) {
						if (chancedoataque <= (salas[salaatual].monstros[i].getChance()
								- heroi.mao2.getChanceDefesa())) {
							heroi.setVida(heroi.getVida() - salas[salaatual].monstros[i].getDano());
							Console.println("Monstro acertou. ");
						} else if (chancedoataque > (salas[salaatual].monstros[i].getChance()
								- heroi.mao2.getChanceDefesa())) {
							Console.println("Monstro Errou.");
						}
					} else if (heroi.mao2 != null && heroi.mao2.getNumero() != 5) {
						chancedoataque = random.nextInt(101);
						if (chancedoataque <= salas[salaatual].monstros[i].getChance()) {
							if (salas[salaatual].monstros[i].getDano() - heroi.mao2.getDefesaArmaduras() > 0) {
								heroi.setVida(heroi.getVida()
										- (salas[salaatual].monstros[i].getDano() - heroi.mao2.getDefesaArmaduras()));
								Console.println("Monstro acertou. ");
							}
						} else if (chancedoataque > salas[salaatual].monstros[i].getChance()) {
							Console.println("Monstro Errou.");
						}
					} else if (chancedoataque <= salas[salaatual].monstros[i].getChance()) {
						heroi.setVida(heroi.getVida() - salas[salaatual].monstros[i].getDano());
					} else if (chancedoataque > salas[salaatual].monstros[i].getChance()) {
						Console.println("Monstro Errou.");
					}
				} else {
					salas[salaatual].monstros[i].setExisteInimigo(false);
				}
			} else {
				Console.println("Voc� errou.");
			}
		}
	}
}
