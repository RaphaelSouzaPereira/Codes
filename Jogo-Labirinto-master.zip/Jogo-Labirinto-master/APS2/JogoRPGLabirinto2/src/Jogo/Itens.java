package Jogo;

public class Itens {
		int numero;
		int defesaArmaduras;
		int danoArma;
		int chanceArma;
		int chanceDefesa;
		boolean existeItem = false;
		
		public int getChanceDefesa() {
			return chanceDefesa;
		}
		public void setChanceDefesa(int chanceDefesa) {
			this.chanceDefesa = chanceDefesa;
		}
		
		public int getNumero() {
			return numero;
		}
		public void setNumero(int numero) {
			this.numero = numero;
		}
		public boolean isExisteItem() {
			return existeItem;
		}
		public void setExisteItem(boolean existeItem) {
			this.existeItem = existeItem;
		}
		
		public int getDefesaArmaduras() {
			return defesaArmaduras;
		}
		public void setDefesaArmaduras(int defesaArmaduras) {
			this.defesaArmaduras = defesaArmaduras;
		}
		public int getDanoArma() {
			return danoArma;
		}
		public void setDanoArma(int danoArma) {
			this.danoArma = danoArma;
		}
		public int getChanceArma() {
			return chanceArma;
		}
		public void setChanceArma(int chanceArma) {
			this.chanceArma = chanceArma;
		}
		public boolean isExiste() {
			return existeItem;
		}
		public void setExiste(boolean existe) {
			this.existeItem = existe;
		}

}
