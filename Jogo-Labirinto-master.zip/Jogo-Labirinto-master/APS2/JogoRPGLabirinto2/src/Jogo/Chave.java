package Jogo;

public class Chave {

	int tipodechave;
	boolean existe = false;
	

	public boolean isExiste() {
		return existe;
	}

	public void setExiste(boolean existe) {
		this.existe = existe;
	}

	public void setNumero(int numero) {
		tipodechave = numero;
	}
	
	public int getNumero(){
		return this.tipodechave;
	}
}
