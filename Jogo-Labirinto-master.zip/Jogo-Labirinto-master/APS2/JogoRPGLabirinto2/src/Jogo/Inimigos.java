package Jogo;

import com.senac.SimpleJava.Graphics.Image;

public class Inimigos {
	
	int vida;
	int dano;
	Image fotoMonstro;
	int chance;
	int tipo;
	boolean existeInimigo = false;	
	
	public Image getFotoMonstro() {
		return fotoMonstro;
	}
	public void setFotoMonstro(Image fotoMonstro) {
		this.fotoMonstro = fotoMonstro;
	}	
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public int getDano() {
		return dano;
	}
	public void setDano(int dano) {
		this.dano = dano;
	}
	
	public int getChance() {
		return chance;
	}
	public void setChance(int chance) {
		this.chance = chance;
	}
	public boolean isExisteInimigo() {
		return existeInimigo;
	}
	public void setExisteInimigo(boolean existeInimigo) {
		this.existeInimigo = existeInimigo;
	}
	
	
	
}
