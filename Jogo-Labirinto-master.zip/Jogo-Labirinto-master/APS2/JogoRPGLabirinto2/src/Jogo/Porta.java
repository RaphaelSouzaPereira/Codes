package Jogo;

import com.senac.SimpleJava.Graphics.Image;

public class Porta{

	int sorteio;
	int proximasala;
	Image porta;
	boolean existe = false;
	boolean existearmadilha = false;
	boolean existetranca = false;
	
	public boolean isExistearmadilha() {
		return existearmadilha;
	}

	public void setExistearmadilha(boolean existearmadilha) {
		this.existearmadilha = existearmadilha;
	}

	public boolean isExistetranca() {
		return existetranca;
	}

	public void setExistetranca(boolean existetranca) {
		this.existetranca = existetranca;
	}
	
	public Image getPorta(){
		return this.porta;
	}
	
	public void setPorta(Image porta) {
		this.porta = porta;
	}
	public boolean isExiste() {
		return existe;
	}

	public void setExiste(boolean existe) {
		this.existe = existe;
	}

	public void setNumero(int numero) {
		sorteio = numero;

	}

	public int getNumero() {
		return this.sorteio;
	}

	public int getProximasala() {
		return proximasala;
	}

	public void setProximasala(int proximasala) {
		this.proximasala = proximasala;
	}




}
