package Jogo;

import java.io.IOException;
import java.util.Random;

public class Sala {

	int numerodasala;
	int i = 0;
	String direcao;
	Random sorteioMonstro = new Random();
	int testeMonstro;
	Porta[] portas = new Porta[6];
	Inimigos[] monstros = new Inimigos[4];
	Itens equipamentos = new Itens();
	Chave chave = new Chave();

	public Sala(int j) {
		this.numerodasala = j;
	}

	public void criaItem() {
		int sorteioItens = sorteioMonstro.nextInt(2);
		if (sorteioItens == 0) {
			sorteioItens = sorteioMonstro.nextInt(9);
			while (sorteioItens == 0) {
				sorteioItens = sorteioMonstro.nextInt(9);
			}
			if (sorteioItens == 1) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(1);
				equipamentos.setChanceArma(75);
				equipamentos.setDanoArma(1);
			}
			if (sorteioItens == 2) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(2);
				equipamentos.setChanceArma(80);
				equipamentos.setDanoArma(2);
			}
			if (sorteioItens == 3) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(3);
				equipamentos.setChanceArma(85);
				equipamentos.setDanoArma(3);
			}
			if (sorteioItens == 4) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(4);
				equipamentos.setChanceArma(65);
				equipamentos.setDanoArma(5);
			}
			if (sorteioItens == 5) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(5);
				equipamentos.setChanceDefesa(25);
				;
			}
			if (sorteioItens == 6) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(6);
				equipamentos.setDefesaArmaduras(2);
			}
			if (sorteioItens == 7) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(7);
				equipamentos.setDefesaArmaduras(3);
			}
			if (sorteioItens == 8) {
				equipamentos.setExiste(true);
				equipamentos.setNumero(8);
				equipamentos.setDefesaArmaduras(5);
			}

		}
	}

	public void criaChaves() {
		int sorteiochaves = sorteioMonstro.nextInt(2);
		if (sorteiochaves == 0) {
			sorteiochaves = sorteioMonstro.nextInt(5);
			while (sorteiochaves == 0) {
				sorteiochaves = sorteioMonstro.nextInt(5);
			}
			if (sorteiochaves == 1) {
				chave.setNumero(1);
				chave.setExiste(true);
			}
			if (sorteiochaves == 2) {
				chave.setNumero(2);
				chave.setExiste(true);
			}
			if (sorteiochaves == 3) {
				chave.setNumero(3);
				chave.setExiste(true);
			}
			if (sorteiochaves == 4) {
				chave.setNumero(4);
				chave.setExiste(true);
			}
		}
	}

	public void setI(String direcao, int proximasala) throws IOException {
		if (direcao.equals("south")) {
			portas[0] = new Porta();
			portas[0].setExiste(true);
			portas[0].setProximasala(proximasala);
			testeMonstro = sorteioMonstro.nextInt(101);
			if (testeMonstro  >= 70) {
				monstros[0] = new Inimigos();
				testeMonstro = sorteioMonstro.nextInt(3);
				if (testeMonstro == 0) {
					monstros[0].setExisteInimigo(true);
					monstros[0].setChance(80);
					monstros[0].setDano(2);
					monstros[0].setVida(2);
					monstros[0].setTipo(testeMonstro);
				} else if (testeMonstro == 1) {
					monstros[0].setExisteInimigo(true);
					monstros[0].setChance(75);
					monstros[0].setDano(4);
					monstros[0].setVida(4);
					monstros[0].setTipo(testeMonstro);
				} else if (testeMonstro == 2) {
					monstros[0].setExisteInimigo(true);
					monstros[0].setChance(50);
					monstros[0].setDano(6);
					monstros[0].setVida(6);
					monstros[0].setTipo(testeMonstro);
				}
			}
			testeMonstro = sorteioMonstro.nextInt(101);
			if(testeMonstro > 50){
				portas[0].setExistetranca(true);
			}
			if(testeMonstro < 50 && testeMonstro > 30){
				portas[0].setExistearmadilha(true);
			}

		}
		if (direcao.equals("north")) {
			portas[1] = new Porta();
			portas[1].setExiste(true);
			portas[1].setProximasala(proximasala);
			testeMonstro = sorteioMonstro.nextInt(101);
			if (testeMonstro   >= 70) {
				monstros[1] = new Inimigos();
				testeMonstro = sorteioMonstro.nextInt(3);
				if (testeMonstro  == 0) {
					monstros[1].setExisteInimigo(true);
					monstros[1].setChance(80);
					monstros[1].setDano(2);
					monstros[1].setVida(2);
					monstros[1].setTipo(testeMonstro);
				} else if (testeMonstro == 1) {
					monstros[1].setExisteInimigo(true);
					monstros[1].setChance(75);
					monstros[1].setDano(4);
					monstros[1].setVida(4);
					monstros[1].setTipo(testeMonstro);
				} else if (testeMonstro == 2) {
					monstros[1].setExisteInimigo(true);
					monstros[1].setChance(50);
					monstros[1].setDano(6);
					monstros[1].setVida(6);
					monstros[1].setTipo(testeMonstro);
				}
			}
			testeMonstro = sorteioMonstro.nextInt(101);
			if(testeMonstro > 50){
				portas[1].setExistetranca(true);
			}
			if(testeMonstro < 50 && testeMonstro > 30){
				portas[1].setExistearmadilha(true);
			}
		}
		if (direcao.equals("east")) {
			portas[2] = new Porta();
			portas[2].setExiste(true);
			portas[2].setProximasala(proximasala);
			testeMonstro = sorteioMonstro.nextInt(101);
			if (testeMonstro >= 70) {
				monstros[2] = new Inimigos();
				testeMonstro = sorteioMonstro.nextInt(3);
				if (testeMonstro == 0) {
					monstros[2].setExisteInimigo(true);
					monstros[2].setChance(80);
					monstros[2].setDano(2);
					monstros[2].setVida(2);
					monstros[2].setTipo(testeMonstro);
				} else if (testeMonstro == 1) {
					monstros[2].setExisteInimigo(true);
					monstros[2].setChance(75);
					monstros[2].setDano(4);
					monstros[2].setVida(4);
					monstros[2].setTipo(testeMonstro);
				} else if (testeMonstro == 2) {
					monstros[2].setExisteInimigo(true);
					monstros[2].setChance(50);
					monstros[2].setDano(6);
					monstros[2].setVida(6);
					monstros[2].setTipo(testeMonstro);
				}
			}
			testeMonstro = sorteioMonstro.nextInt(101);
			if(testeMonstro > 50){
				portas[2].setExistetranca(true);
			}
			if(testeMonstro < 50 && testeMonstro > 30){
				portas[2].setExistearmadilha(true);
			}
		}
		if (direcao.equals("west")) {
			portas[3] = new Porta();
			portas[3].setExiste(true);
			portas[3].setProximasala(proximasala);
			testeMonstro = sorteioMonstro.nextInt(101);
			if (testeMonstro >= 70) {
				monstros[3] = new Inimigos();
				testeMonstro = sorteioMonstro.nextInt(3);
				if (testeMonstro == 0) {
					monstros[3].setExisteInimigo(true);
					monstros[3].setChance(80);
					monstros[3].setDano(2);
					monstros[3].setVida(2);
					monstros[3].setTipo(testeMonstro);
				} else if (testeMonstro == 1) {
					monstros[3].setExisteInimigo(true);
					monstros[3].setChance(75);
					monstros[3].setDano(4);
					monstros[3].setVida(4);
					monstros[3].setTipo(testeMonstro);
				} else if (testeMonstro == 2) {
					monstros[3].setExisteInimigo(true);
					monstros[3].setChance(50);
					monstros[3].setDano(6);
					monstros[3].setVida(6);
					monstros[3].setTipo(testeMonstro);
				}
			}
			testeMonstro = sorteioMonstro.nextInt(101);
			if(testeMonstro > 50){
				portas[3].setExistetranca(true);
			}
			if(testeMonstro < 50 && testeMonstro > 30){
				portas[3].setExistearmadilha(true);
			}
		}

	}

	public void setEscadaSobe(int proximasala) {
		portas[4] = new Porta();
		portas[4].setExiste(true);
		portas[4].setProximasala(proximasala);
	}

	public void setEscadaDesce(int proximasala) {
		portas[5] = new Porta();
		portas[5].setExiste(true);
		portas[5].setProximasala(proximasala);
	}

	public boolean verificaporta(int i) {
		if (portas[i] == null) {
			return false;
		} else {
			return true;
		}

	}

	public boolean verificamonstro(int i) {
		if (monstros[i] == null) {
			return false;
		} else {
			return monstros[i].isExisteInimigo();
		}

	}

	public boolean verificachave() {
		if (chave == null) {
			return false;
		} else {
			return chave.isExiste();
		}

	}

	public boolean verificaitens() {
		if (equipamentos == null) {
			return false;
		} else {
			return equipamentos.isExiste();
		}

	}

	public int getNumeroDaSala() {
		return this.numerodasala;
	}

	public int getProximaSala() {
		return this.getProximaSala();
	}

	public String getDirecao() {
		return direcao;
	}

	public void setDirecao(String direcao) {
		this.direcao = direcao;
	}

}
