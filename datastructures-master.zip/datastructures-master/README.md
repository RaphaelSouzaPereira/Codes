# Estruturas de Dados e Algoritmos

Este projeto traz uma coleção de classes Java, utilizadas na disciplina de
[Algoritmos e
Programação III](http://rafaeljeffman.com/_.php?c=algoritmos3),
da [Faculdade Senac
Porto Alegre](http://www.senacrs.com.br/unidades.asp?unidade=63).

Estas classes mostram uma possível implementação das estruturas, técnicas
de desenvolvimento, com o objetivo de orientarem os alunos em suas
implementações.

