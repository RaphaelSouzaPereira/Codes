/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Paciente {
    
    private String nome;
    private int cpf;
    private LocalDate dataDeNascimento;
    private DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/YYYY");
    
    public Paciente(String nome, int cpf, LocalDate dataDeNascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataDeNascimento = dataDeNascimento;
    }
    
    @Override
    public String toString() {
        return "Paciente " + this.nome + " de cpf " + this.cpf + " que nasceu na data " + this.dataDeNascimento.format(formatador);        
    }
    
}
