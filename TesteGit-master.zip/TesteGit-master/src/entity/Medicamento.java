/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Medicamento {

    private int codigo;
    private String nome;
    private String descricao;

    public Medicamento(int codigo, String nome, String descricao) {
        this.nome = nome;
        this.codigo = codigo;
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "O nome do medicamento é " + this.nome + " seu codigo é " + this.codigo + " e sua descrição é " + this.descricao;
    }

}
