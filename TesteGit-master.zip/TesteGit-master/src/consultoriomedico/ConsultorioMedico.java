﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultoriomedico;

import entity.Medicamento;
import entity.Paciente;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import util.Console;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 */
public class ConsultorioMedico {

    private static ArrayList<Paciente> listaDePacientes;
    private static ArrayList<Medicamento> listaDeMedicamentos;

    public static void main(String[] args) {

	System.out.println("Atualizando Testando Git");
        ArrayList<Paciente> listaDePacientes = new ArrayList<Paciente>();
        int exit = 0;
        do {
            switch (menu()) {
                case 1:
                    cadastrarPaciente(listaDePacientes);
                    break;
                case 2:
                    listarPacientes(listaDePacientes);
                    break;
                case 3:
                    cadastrarMedicamento(listaDeMedicamentos);
                    break;
                case 4:
                    listarMedicamentos(listaDeMedicamentos);
                    break;
                case 5:
                    exit = 5;
                    break;
                default:
                    System.out.println("Escolheu uma opção inválida");
                    break;
            }

        } while (exit != 5);
        System.out.println("Você saiu do sistema.");
        System.exit(0);
    }

    private static int menu() {
        Console console = new Console();
        int opcao;
        opcao = console.scanInt("Escolha uma opção do menu:"
                + "\n1 - para cadastrar um paciente."
                + "\n2- para listar pacientes cadastrados."
                + "\n3- para cadastrar um medicamento."
                + "\n4- para listar medicamentos cadastrados."
                + "\n5- para fechar o sistema.\n");
        console = null;
        return opcao;
    }

    private static void cadastrarPaciente(ArrayList<Paciente> listaDePacientes) {
        Console console = new Console();
        Paciente pacienteCadastrado;
        String nome = console.scanString("Digite o nome do paciente: \n");
        int cpf = console.scanInt("Digite o cpf do paciente: \n");
        int dia = console.scanInt("Digite a data de nascimento do paciente: \n Digite o dia: \n");
        int mes = console.scanInt("Digite o mes: \n");
        int ano = console.scanInt("Digite o ano: \n");
        LocalDate dataDeNascimento = LocalDate.of(ano, mes, dia);
        pacienteCadastrado = new Paciente(nome, cpf, dataDeNascimento);
        listaDePacientes.add(pacienteCadastrado);
        console = null;
        pacienteCadastrado = null;

    }

    private static void listarPacientes(ArrayList<Paciente> listaDePacientes) {
        for (Paciente paciente : listaDePacientes) {
            System.out.println(paciente);
        }
        System.out.println("Digite enter para voltar;");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

    private static void cadastrarMedicamento(ArrayList<Medicamento> listaDeMedicamentos) {
        Console console = new Console();
        Medicamento medicamentoCadastrado;
        int codigo = console.scanInt("Digite o codigo do medicamento: \n");
        String nome = console.scanString("Digite o nome do paciente: \n");
        String descricao = Console.scanString("Digite a descrição do produto: \n");
        medicamentoCadastrado = new Medicamento(codigo, nome, descricao);
        listaDeMedicamentos.add(medicamentoCadastrado);
        console = null;
        medicamentoCadastrado = null;
    }

    private static void listarMedicamentos(ArrayList<Medicamento> listaDeMedicamentos) {
    for (Medicamento medicamento : listaDeMedicamentos) {
            System.out.println(medicamento);
        }
        System.out.println("Aperte enter para voltar;");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

}
