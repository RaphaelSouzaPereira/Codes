/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Agendamento {

    private LocalDateTime dataDaConsulta;
    private DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm");

    public Agendamento(LocalDateTime dataDaConsulta) {
        this.dataDaConsulta = dataDaConsulta;
    }

    @Override
    public String toString() {
        return "Consulta marcada em: " + this.dataDaConsulta.format(formatador);
    }

}
