/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.faculdade.trabalho.cantina.entidades;

import java.util.ArrayList;

/**
 *
 * @author RaphaeldeSouzaPereir
 */
public class Pedido {

    private int porta;
    private ArrayList<Cardapio> compras = new ArrayList<>();
    private int preco = 0;

    public Pedido() {

    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public ArrayList<Cardapio> getCompras() {
        return compras;
    }

    public void setCompras(ArrayList<Cardapio> compras) {
        this.compras = compras;
    }

}
