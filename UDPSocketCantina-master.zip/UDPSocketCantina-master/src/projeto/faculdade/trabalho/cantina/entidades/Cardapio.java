/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.faculdade.trabalho.cantina.entidades;

import java.util.Objects;

/**
 *
 * @author RaphaeldeSouzaPereir
 */
public class Cardapio {

    String nomeDoProduto;
    int precoDoProduto;

    public Cardapio(String nomeDoProduto, int precoDoProduto) {
        this.nomeDoProduto = nomeDoProduto;
        this.precoDoProduto = precoDoProduto;
    }

    public String getNomeDoProduto() {
        return nomeDoProduto;
    }

    public void setNomeDoProduto(String nomeDoProduto) {
        this.nomeDoProduto = nomeDoProduto;
    }

    public int getPrecoDoProduto() {
        return precoDoProduto;
    }

    public void setPrecoDoProduto(int precoDoProduto) {
        this.precoDoProduto = precoDoProduto;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.nomeDoProduto);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cardapio other = (Cardapio) obj;
        if (!Objects.equals(this.nomeDoProduto, other.nomeDoProduto)) {
            return false;
        }
        return true;
    }

}
