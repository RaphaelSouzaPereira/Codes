/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.faculdade.trabalho.cantina.inicializador;

import java.util.ArrayList;
import projeto.faculdade.trabalho.cantina.entidades.Aluno;
import projeto.faculdade.trabalho.cantina.entidades.Cardapio;

/**
 *
 * @author RaphaeldeSouzaPereir
 */
public class Inicializador {

    public ArrayList<Aluno> alunos = new ArrayList<>();
    public ArrayList<Cardapio> cardapio = new ArrayList<>();

    public Inicializador() {        
        alunos.add(new Aluno(300, "1", "1"));
        alunos.add(new Aluno(8, "2", "2"));
        alunos.add(new Aluno(5, "3", "3"));
        cardapio.add(new Cardapio("Empada", 5));
        cardapio.add(new Cardapio("Coxinha", 3));
        cardapio.add(new Cardapio("Refrigerante", 10));

    }

    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    public ArrayList<Cardapio> getCardapio() {
        return cardapio;
    }

}
