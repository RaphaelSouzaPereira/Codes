package cantinaudp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import projeto.faculdade.trabalho.cantina.inicializador.Inicializador;

public class UDPServer {

    static String usuario;
    static String pedido;
    static String senha;
    static String portaCliente;
    static int saldoParaEnviar;
    static int portaUsuario;
    static int portaAtendente = 7004;
    static InetAddress adressAtendente;
    public static Inicializador inicializador;

    public static void main(String args[]) {
        DatagramSocket aSocket = null;
        String[] respostas;
        inicializador = new Inicializador();
        try {
            aSocket = new DatagramSocket(7000);
            while (true) {
                byte[] buffer = new byte[1000];
                System.out.println("ENTREI SERVIDOR");
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(request);
                String frase = new String(request.getData());
                String array[] = frase.split(":");
                pedido = retornaPedido(request.getData());
                if (pedido.trim().equals("login")) {
                    loginRequest(aSocket, request.getData(), request);
                } else if (pedido.trim().equals("pedido")) {
                    boolean temSaldo = false;
                    temSaldo = avaliaSaldoUsuario(array);
                    if (temSaldo) {
                        pedidoRequest(aSocket, request.getData(), request);
                    } else {
                        faltaSaldoRequest(aSocket, request.getData(), request);
                    }
                } else if (pedido.trim().equals("pedidoPronto")) {
                    enviarPedidoProntoParaCliente(aSocket, array[1], request);//continuar daqui e fazer o teste se o usuario tem saldo e descontar o saldo dele
                }

            }
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null) {
                aSocket.close();
            }
        }
    }

    private static void loginRequest(DatagramSocket aSocket, byte[] data, DatagramPacket request) throws IOException {
        boolean testaLogin = false;
        System.out.println("ENTREI NO LOGIN REQUEST");
        String frase = new String(data);
        String array[] = frase.split(":");
        usuario = array[1];
        senha = array[2];
        portaCliente = array[3].trim();
        testaLogin = validaLogin(usuario, senha, portaCliente);
        if (testaLogin) {
            String sucessoLogin = "cardapio:"+saldoParaEnviar;
            byte[] m = sucessoLogin.getBytes();
            DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort());
            aSocket.send(reply);
        } else {
            String falhaLogin = "falhou";
            byte[] m = falhaLogin.getBytes();
            DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort());
            aSocket.send(reply);
        }

    }

    private static String retornaPedido(byte[] data) {
        String frase = new String(data);
        String array[] = frase.split(":");

        return array[0];
    }

    private static boolean validaLogin(String usuario, String senha, String porta) {
        System.out.println("ENTREI NO VALIDA LOGIN");
        for (int i = 0; i < inicializador.getAlunos().size(); i++) {
            if (inicializador.getAlunos().get(i).getMatricula().trim().equals(usuario) && inicializador.getAlunos().get(i).getSenha().trim().equals(senha)) {
                inicializador.getAlunos().get(i).setPorta(porta.trim());
                saldoParaEnviar = inicializador.getAlunos().get(i).getCreditos();
                return true;
            }
        }
        return false;
    }

    private static void pedidoRequest(DatagramSocket aSocket, byte[] data, DatagramPacket request) throws IOException {
        System.out.println("ENTREI NO PEDIDO REQUEST");
        request = new DatagramPacket(data, data.length, request.getAddress(), portaAtendente);
        aSocket.send(request);

    }

    private static void enviarPedidoProntoParaCliente(DatagramSocket aSocket, String texto, DatagramPacket request) throws IOException {
        System.out.println("ENTREI NO ENVIA PEDIDO PRONTO CLIENTE");
        byte[] data = new byte[1000];
        String pedidoPronto = "pedidopronto";
        data = pedidoPronto.getBytes();
        int portaDoClientePedidoPronto = Integer.parseInt(texto.trim());
        request = new DatagramPacket(data, data.length, request.getAddress(), portaDoClientePedidoPronto);
        aSocket.send(request);
        for (int i = 0; i < inicializador.getAlunos().size(); i++) {
            if (inicializador.getAlunos().get(i).getPorta().trim().equals(texto)) {
                inicializador.getAlunos().get(i).setPorta("");
            }
        }
    }

    private static boolean avaliaSaldoUsuario(String[] array) {
        System.out.println("ENTREI NO VALIDA SALDO");
        int valorTotal = 0;
        for (int i = 0; i < inicializador.getAlunos().size(); i++) {
            if (inicializador.getAlunos().get(i).getPorta().trim().equals(array[1])) {
                for (int a = 3; a < array.length; a++) {
                    if (a % 2 == 1) {
                        valorTotal += Integer.parseInt(array[a].trim());
                    }
                }
                System.out.println("Valor total do Pedido: " + valorTotal);
                if (valorTotal <= inicializador.getAlunos().get(i).getCreditos()) {
                    System.out.println(inicializador.getAlunos().get(i).getMatricula() + " SALDO " + inicializador.getAlunos().get(i).getCreditos());
                    inicializador.getAlunos().get(i).setCreditos(inicializador.getAlunos().get(i).getCreditos() - valorTotal);
                    System.out.println(inicializador.getAlunos().get(i).getMatricula() + " SALDO " + inicializador.getAlunos().get(i).getCreditos());
                    return true;
                }
            }
        }
        return false;
    }
    
    private static void faltaSaldoRequest(DatagramSocket aSocket, byte[] data, DatagramPacket request) throws IOException {
        String semSaldo = "semsaldo";
        data = semSaldo.getBytes();
        request = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());
        aSocket.send(request);
    }
}
