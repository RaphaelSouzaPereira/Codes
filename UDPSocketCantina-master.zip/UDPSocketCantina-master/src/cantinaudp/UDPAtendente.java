package cantinaudp;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import projeto.faculdade.trabalho.cantina.entidades.Cardapio;
import projeto.faculdade.trabalho.cantina.entidades.Pedido;

public class UDPAtendente {

    static GridLayout relatorio;
    static GridLayout atendimento;
    static String pedidoString;
    static String servidorString;
    static String port = "7004";//porta unica para cada cliente enviar para servidor e enviar junto ao pedido a porta que vai ser o id do processo.
    static int porta = 7004;
    static int serverPort = 7000;
    static ArrayList<Pedido> listaDePedido = new ArrayList<>();
    static String portaDoPedido;

    public static void main(String args[]) throws UnknownHostException {
        // args give message contents and server hostname
        DatagramSocket aSocket = null;
        InetAddress endereco = InetAddress.getByName("localhost");
        try {
            aSocket = new DatagramSocket(porta);
            InetAddress aHost = InetAddress.getByName("localhost");
            while (true) {
                System.out.println("ATENDENTE ESPERANDO SERVIDOR");
                byte[] buffer = new byte[1000];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(request);
                servidorString = retornaPedido(request.getData());
                if (servidorString.trim().equals("pedido")) {
                    System.out.println("ENTREI NO PEDIDO");
                    telaCriaPedido(aSocket, request.getData(), request);
                }
            }

        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null) {
                aSocket.close();
            }
        }
    }

    private static String retornaPedido(byte[] data) {
        String frase = new String(data);
        String array[] = frase.split(":");

        return array[0];
    }

    private static void montaEnvio(int porta) {
        pedidoString = "pedidoPronto:" + porta;
    }

    private static void telaCriaPedido(DatagramSocket aSocket, byte[] data, DatagramPacket request) {
        System.out.println("TELA DE PEDIDO DO CLIENTE");
        String frase = new String(data);
        String array[] = frase.split(":");
        JFrame frame = new JFrame("Pedido: " + array[1]);
        frame.setSize((frase.length()-200), 200);
        atendimento = new GridLayout(2, 1, 10, 10);
        frame.setLayout(atendimento);
        Pedido pedido = new Pedido();
        pedido.setPorta(Integer.parseInt(array[1].trim()));
        for (int i = 2; i < array.length; i++) {
            if (i % 2 == 0) {
                Cardapio itemPedido = new Cardapio(array[i].trim(), Integer.parseInt(array[i + 1].trim()));
                pedido.getCompras().add(itemPedido);
                pedido.setPreco(pedido.getPreco() + Integer.parseInt(array[i + 1].trim()));
                listaDePedido.add(pedido);
            }
        }
        JButton botao = new JButton("Terminar Pedido");
        botao.addActionListener(new botaoEnviarPedidoPronto(botao, pedido, data, request, aSocket, frame));
        JTextArea texto = new JTextArea(frase);
        Font fonte = new Font("Serif", Font.PLAIN, 35);
        texto.setFont(fonte);
        frame.add(texto);
        frame.add(botao);
        frame.setVisible(true);
    }

    private static class botaoEnviarPedidoPronto implements ActionListener {

        private JButton botao;
        private Pedido pedido;
        private byte[] data;
        private DatagramPacket request;
        private DatagramSocket aSocket;
        private JFrame frame;

        private botaoEnviarPedidoPronto(JButton botao, Pedido pedido, byte[] data, DatagramPacket request, DatagramSocket aSocket, JFrame frame) {
            this.botao = botao;
            this.pedido = pedido;
            this.data = data;
            this.request = request;
            this.aSocket = aSocket;
            this.frame = frame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                enviarPedidoPronto(pedido.getPorta());
            } catch (UnknownHostException ex) {
                System.out.println("Unknow: " + ex.getMessage());
            } catch (SocketException ex) {
                System.out.println("Socket: " + ex.getMessage());
            } catch (IOException ex) {
                System.out.println("IO: " + ex.getMessage());
            }
        }

        private void enviarPedidoPronto(int porta) throws UnknownHostException, IOException {
            System.out.println("ENTREI NO ENVIAR PEDIDO PRONTO");
            InetAddress aHost = InetAddress.getByName("localhost");
            montaEnvio(porta);
            data = pedidoString.getBytes();
            request = new DatagramPacket(data, data.length, aHost, serverPort);
            aSocket.send(request);
            pedidoString = "";
            frame.setVisible(false);
        }

    }

}
