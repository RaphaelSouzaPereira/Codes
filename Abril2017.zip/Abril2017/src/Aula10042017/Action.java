package Aula10042017;

import com.senac.SimpleJava.Console;

public class Action {
	
	
	private Object command;

	public Action(String string) {
		this.command = command;
	}

	public void execute() {
		Console.println("Executando a acao "+command);
		
	}

}
