package Lista;

public class No {
		
	
		private No ant; 
		private No prox;
		private Object dado;

		//construtor
		/* Cria um novo no. */
		public No(Object dado){
			this.ant = null;
			this.prox = null;
			this.dado = dado;
			}
//---------------------------m�todos-------------------/		
	    /* Testa se existe um No apos esse no. */
	    public boolean hasNext(){
	    	if(prox == null){
	    		return false;
	    	}else
	    		return true;
	    }
	    
	    /* Testa se existe um No antes desse no. */
	    public boolean hasPrevious(){
	    	if(ant == null){
	    		return false;
	    	}else
	    		return true;
		}
	    
	    /* Retorna o pr�ximo No. */
	    public No next(){
	    	return prox; 
		}
	    
	    /* Retorna o No anterior. */
	    public No previous(){ 
			return ant; 
			}
	    
	    /* Insere um No ap�s esse no. */
	    public void insertAfter(No novo){ 
			this.next().setAnt(novo);
			novo.setProx(this.next());
			novo.setAnt(this);
			this.setProx(novo);
			}
	    
	    /* Insere um No antes desse no. */
	    public void insertBefore(No novo){ 
			this.previous().setProx(novo);
			novo.setAnt(this.previous());
			novo.setProx(this);
			this.setAnt(novo);
			
			}
	    
	    /* Remove o no */
	    //public void remove();
	    
	    
	    /* Recupera o dado armazenado. */
	    public Object getData() { 
			return dado; 
			}

		//Set Anterior
		public void setAnt(No ant) {
			this.ant = ant;
		}

		//Set Proximo
		public void setProx(No prox) {
			this.prox = prox;
		}
		
		}	
		
		
		
		
		
