package Lista;

public class ListaEncadeada {
	
	private No head;
	private No tail;
	
	public ListaEncadeada(){
		head = null;
		tail = null;
	}
	
    /* Insere o objeto no fim da lista. */
    public void append(Object o) {	
    	No novo = new No(o);
    	if(head == null){
    		head = novo;
    		head.setProx(novo);
    		head.setAnt(novo);
    		tail = head;
    	
    	}else{
    		tail.setProx(novo);
        	novo.setAnt(tail);
        	novo.setProx(null);
    		tail = novo;
           
    	}
	}
    
    /* Insere o objeto no inicio da lista. */
    public void addFirst(Object o) {
    	No novo = new No(o);
    	if(head == null){
    	head = novo;
    	head.setProx(head);
    	head.setAnt(null);
    	tail = head;
    	}else{
    		head.setAnt(novo);
    		novo.setProx(head);
    		novo.setAnt(null);
    		head = novo;
    	}
    		
    	
	}
    
    /* Remove o objeto da lista. */
   // public void remove(Object o) {
    
    /* Recupera o primeiro No da lista. */
    public No getFirst() {	
		return head;
	}
    
    /* Recupera o ultimo No da lista. */
    public No getLast() {
    	return tail;
	}
    
    /* Testa se o objeto existe na lista. */
    public Object hasObject(Object o) {
    	if(head != null);
		return o;
    }
}
