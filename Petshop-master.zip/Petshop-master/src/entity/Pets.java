/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Pets {

    private String nome;
    private String tipo;
    private Cliente cliente;

    public Pets(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


    @Override
    public String toString() {
        return "O nome do medicamento é " + this.nome + " seu cliente é " + this.cliente;
    }

   
}
