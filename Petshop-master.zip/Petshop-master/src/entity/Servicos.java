/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;


/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Servicos {

 
    private int codigo;
    private String nome;
    private String tipoDeAtendimento;
    private double preco;

    public Servicos(int codigo, String nome, String tipoDeAtendimento, Double preco) {
        this.nome = nome;
        this.codigo = codigo;
        this.tipoDeAtendimento = tipoDeAtendimento;
        this.preco = preco;
    }
    
    @Override
    public String toString() {
        return this.codigo + " - " + this.nome + " - " + this.tipoDeAtendimento + " - " +this.preco;
    }


}
