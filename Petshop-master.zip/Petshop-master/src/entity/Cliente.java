/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Cliente {
    
    private String nome;
    private int rg;
    private String telefone;

    
    public Cliente(String nome, int rg, String telefone) {
        this.nome = nome;
        this.rg = rg;
        this.telefone = telefone;

    }
    
    @Override
    public String toString() {
        return "Cliente " + this.nome + " de rg " + this.rg + " seu telefone é " + this.telefone;        
    }
    
}
