/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petshop;

import entity.Servicos;
import entity.Cliente;
import entity.Pets;
import java.util.ArrayList;
import java.util.Scanner;
import util.Console;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 */
public class Petshop {

    private static ArrayList<Cliente> listaDeClientes;
    private static ArrayList<Pets> listaDePets;
    private static ArrayList<Servicos> listaDeServicos;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int exit = 0;
        do {
            switch (menu()) {
                case 1:
                    cadastrarClientes(listaDeClientes);
                    break;
                case 2:
                    listarClientes(listaDeClientes);
                    break;
                case 3:
                    cadastrarPets(listaDePets, listaDeClientes);
                    break;
                case 4:
                    listarPets(listaDePets);
                    break;
                case 5:
                    cadastrarServicos(listaDeServicos);
                    break;
                case 6:
                    listarServicos(listaDeServicos);
                    break;
                case 7:
                    exit = 7;
                    break;
                default:
                    System.out.println("Escolheu uma opção inválida");
                    break;
            }

        } while (exit != 7);
        System.out.println("Você saiu do sistema.");
        System.exit(0);
    }

    private static int menu() {
        Console console = new Console();
        int opcao;
        opcao = console.scanInt("Escolha uma opção do menu:"
                + "\n1 - para cadastrar um Cliente."
                + "\n2- para listar Clientes cadastrados."
                + "\n3- para cadastrar um Pet."
                + "\n4- para listar Pets cadastrados."
                + "\n5- para cadastrar Serviços."
                + "\n6- para listar Serviços cadastrados."
                + "\n- para fechar o sistema.\n");
        console = null;
        return opcao;
    }

    private static void cadastrarClientes(ArrayList<Cliente> listaDeClientes) {
        Console console = new Console();
        Cliente clienteCadastrado;
        String nome = console.scanString("Digite o nome do cliente: \n");
        int rg = console.scanInt("Digite o rg do cliente: \n");
        String telefone = console.scanString("Digite o telefone do cliente: \n");
        clienteCadastrado = new Cliente(nome, rg, telefone);
        listaDeClientes.add(clienteCadastrado);
        console = null;
        clienteCadastrado = null;

    }

    private static void listarClientes(ArrayList<Cliente> listaDeClientes) {
        int i = 0;
        for (Cliente cliente : listaDeClientes) {
            System.out.println(i + " - " + cliente);
            i++;
        }
        System.out.println("Digite enter para voltar;");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

    private static void cadastrarPets(ArrayList<Pets> listaDePets, ArrayList<Cliente> listaDeClientes) {
        Console console = new Console();
        Pets petsCadastrado;
        String nome = console.scanString("Digite o nome do pet: \n");
        String descricao = Console.scanString("Digite o tipo de pet: \n");
        listarClientes(listaDeClientes);
        int escolhaDeCliente = console.scanInt("Digite quem é o dono do pet.");
        Cliente dono = listaDeClientes.get(escolhaDeCliente);
        petsCadastrado = new Pets(nome, descricao);
        petsCadastrado.setCliente(dono);
        listaDePets.add(petsCadastrado);
        console = null;
        petsCadastrado = null;
    }

    private static void listarPets(ArrayList<Pets> listaDePets) {
        for (Pets pet : listaDePets) {
            System.out.println(pet);
        }
        System.out.println("Aperte enter para voltar;");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

    private static void cadastrarServicos(ArrayList<Servicos> listaDeServicos) {
        Console console = new Console();
        Servicos servicoCadastrado;
        int codigo = console.scanInt("Digite o codigo do serviço: \n");
        String nome = console.scanString("Digite o nome do serviço: \n");
        String tipo = console.scanString("Digite o tipo de servico(clínico, estético): \n");
        Double preco = console.scanDouble("Digite o valor do serviço: \n");
        servicoCadastrado = new Servicos(codigo, nome, tipo, preco);
        listaDeServicos.add(servicoCadastrado);
        console = null;
        servicoCadastrado = null;

    }

    private static void listarServicos(ArrayList<Servicos> listaDeServicos) {
        int i = 0;
        for (Servicos servico : listaDeServicos) {
            System.out.println(i + " - " + servico);
            i++;
        }
        System.out.println("Digite enter para voltar;");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

}
