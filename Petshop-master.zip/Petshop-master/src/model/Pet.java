/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Pet {

    private int id;
    private String nome;
    private String tipo;
    private String rg;

    public Pet(int id, String nome, String tipo, String rg) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.rg = rg;
    }

    public Pet(String nome, String tipo, String rg) {
        this.nome = nome;
        this.tipo = tipo;
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

}
