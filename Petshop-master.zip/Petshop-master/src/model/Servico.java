/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Raphael de Souza Pereira <raphael.pereira@ibm.com>
 * @param
 * @return
 */
public class Servico {

    private int id;
    private String nome;
    private String tipoDeAtendimento;
    private double preco;

    public Servico(int id, String nome, String tipoDeAtendimento, Double preco) {
        this.nome = nome;
        this.id = id;
        this.tipoDeAtendimento = tipoDeAtendimento;
        this.preco = preco;
    }

    public Servico(String nome, String tipoDeAtendimento, Double preco) {
        this.nome = nome;
        this.tipoDeAtendimento = tipoDeAtendimento;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTipoDeAtendimento() {
        return tipoDeAtendimento;
    }

    public double getPreco() {
        return preco;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTipoDeAtendimento(String tipoDeAtendimento) {
        this.tipoDeAtendimento = tipoDeAtendimento;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

}
