/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDateTime;

/**
 *
 * @author 631610085
 */
public class Venda {

    private int id;
    private int idDoPet;
    private int idServico;
    private LocalDateTime diaHora;
    private Double valorTotalDaVenda;
    private String rgDoCliente;

    public Venda(int idServico, int idDoPet, LocalDateTime diaHora, Double valor, String rgDoCliente) {
        this.idServico = idServico;
        this.idDoPet = idDoPet;
        this.diaHora = diaHora;
        this.rgDoCliente = rgDoCliente;
        this.valorTotalDaVenda = valor;
    }

    public Venda(int id, int idDoPet, int idServico, LocalDateTime diaHora, Double valorTotalDaVenda, String rgDoCliente) {
        this.id = id;
        this.idDoPet = idDoPet;
        this.idServico = idServico;
        this.diaHora = diaHora;
        this.valorTotalDaVenda = valorTotalDaVenda;
        this.rgDoCliente = rgDoCliente;
    }

    public int getIdDoPet() {
        return idDoPet;
    }

    public void setIdDoPet(int idDoPet) {
        this.idDoPet = idDoPet;
    }

    public int getIdServico() {
        return idServico;
    }

    public void setIdServico(int idservico) {
        this.idServico = idservico;
    }

    public LocalDateTime getDiaHora() {
        return diaHora;
    }

    public void setDiaHora(LocalDateTime diaHora) {
        this.diaHora = diaHora;
    }

    public Double getValorTotalDaVenda() {
        return valorTotalDaVenda;
    }

    public void setValorTotalDaVenda(Double valorTotalDaVenda) {
        this.valorTotalDaVenda = valorTotalDaVenda;
    }

    public String getRgDoCliente() {
        return rgDoCliente;
    }

    public void setRgDoCliente(String rgDoCliente) {
        this.rgDoCliente = rgDoCliente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
