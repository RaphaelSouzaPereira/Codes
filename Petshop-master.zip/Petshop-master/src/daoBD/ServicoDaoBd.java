/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoBD;

import dao.ServicoDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Servico;

/**
 *
 * @author rapha
 */
public class ServicoDaoBd implements ServicoDao {

    //Variaveis que fazem a conexao com o banco de dados e executam os comandos sql enviados ao banco e trazendo seus resultados.
    private Connection conexao;
    private PreparedStatement comando;

    /**
     * Metodo que pega uma conexao com o Banco utilizando o connection factory .
     *
     * @param sql
     * @return retorna a conexão com o banco ou estoura erro caso não consiga
     * fazer.
     * @throws SQLException
     */
    public Connection conectar(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql);
        return conexao;
    }

    /**
     * Metodo que conecta com o banco recebendo e pegando o id que está
     * vinculado a row.
     *
     * @param sql
     * @throws SQLException
     */
    public void conectarObtendoId(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
    }

    /**
     * Metodo que fecha a conexao caso ela continue aberta depois de alguma
     * execução retorna uma erro caso nao consiga encerrar
     */
    public void fecharConexao() {
        try {
            if (comando != null) {
                comando.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Erro ao encerrar a conexao");
            throw new BDException(ex);

        }
    }

    @Override
    public void salvar(Servico servico) {
        int id = 0;
        try {
            String sql = "INSERT INTO servico (nome, tipo, preco) "
                    + "VALUES (?,?,?)";

            //Foi criado um novo método conectar para obter o id
            conectarObtendoId(sql);
            comando.setString(1, servico.getNome());
            comando.setString(2, servico.getTipoDeAtendimento());
            comando.setDouble(3, servico.getPreco());
            comando.executeUpdate();
            //Obtém o resultSet para pegar o id
            ResultSet resultado = comando.getGeneratedKeys();
            if (resultado.next()) {
                //seta o id para o objeto
                id = resultado.getInt(1);
                servico.setId(id);
            } else {
                System.err.println("Erro de Sistema - Nao gerou o id conforme esperado!");
                throw new BDException("Nao gerou o id conforme esperado!");
            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao salvar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public void deletar(Servico servico) {
        try {
            String sql = "DELETE FROM servico WHERE id = ?";

            conectar(sql);
            comando.setInt(1, servico.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao deletar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public void atualizar(Servico servico) {
        try {
            String sql = "UPDATE servico set nome=?, tipo=?, preco=? "
                    + "WHERE id=?";

            conectar(sql);
            comando.setString(1, servico.getNome());
            comando.setString(2, servico.getTipoDeAtendimento());
            comando.setDouble(3, servico.getPreco());
            comando.setInt(4, servico.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao atualizar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public List<Servico> listar() {
        List<Servico> listaServicos = new ArrayList<>();

        String sql = "SELECT * FROM servico";

        try {
            conectar(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String tipo = resultado.getString("tipo");
                Double preco = resultado.getDouble("preco");

                Servico servico = new Servico(id, nome, tipo, preco);

                listaServicos.add(servico);

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar os clientes do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (listaServicos);
    }

    @Override
    public Servico procurarPorId(int id) {
        String sql = "SELECT * FROM servico WHERE id = ?";

        try {
            conectar(sql);
            comando.setInt(1, id);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String tipo = resultado.getString("tipo");
                Double preco = resultado.getDouble("preco");
                Servico servico = new Servico(id, nome, tipo, preco);

                return servico;

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar o cliente pelo id do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);
    }

}
