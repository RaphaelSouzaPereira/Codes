/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoBD;

import dao.ClienteDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Cliente;

/**
 * Classe Base do Cliente para ter persistencia e executar e trazer os
 * resultador do banco de dados
 *
 * @author rapha
 */
public class ClienteDaoBd implements ClienteDao {

    //Variaveis que fazem a conexao com o banco de dados e executam os comandos sql enviados ao banco e trazendo seus resultados.
    private Connection conexao;
    private PreparedStatement comando;

    /**
     * Metodo que pega uma conexao com o Banco utilizando o connection factory .
     *
     * @param sql
     * @return retorna a conexão com o banco ou estoura erro caso não consiga
     * fazer.
     * @throws SQLException
     */
    public Connection conectar(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql);
        return conexao;
    }

    /**
     * Metodo que conecta com o banco recebendo e pegando o id que está
     * vinculado a row.
     *
     * @param sql
     * @throws SQLException
     */
    public void conectarObtendoId(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
    }

    /**
     * Metodo que fecha a conexao caso ela continue aberta depois de alguma
     * execução retorna uma erro caso nao consiga encerrar
     */
    public void fecharConexao() {
        try {
            if (comando != null) {
                comando.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Erro ao encerrar a conexao");
            throw new BDException(ex);

        }
    }

    /**
     * Metodo salvar no banco onde recebe o objeto pega seus dados e coloca
     * dentro da query e a executra estourando um erro caso nao consiga gerar o
     * id ou salvar no banco mesmo
     *
     * @param cliente
     */
    @Override
    public void salvar(Cliente cliente) {
        int id = 0;
        try {
            String sql = "INSERT INTO cliente (rg, nome, telefone) "
                    + "VALUES (?,?,?)";

            //Foi criado um novo método conectar para obter o id
            conectarObtendoId(sql);
            comando.setString(1, cliente.getRg());
            comando.setString(2, cliente.getNome());
            comando.setString(3, cliente.getTelefone());
            comando.executeUpdate();
            //Obtém o resultSet para pegar o id
            ResultSet resultado = comando.getGeneratedKeys();
            if (resultado.next()) {
                //seta o id para o objeto
                id = resultado.getInt("id");
                cliente.setId(id);
            } else {
                System.err.println("Erro de Sistema - Nao gerou o id conforme esperado!");
                throw new BDException("Nao gerou o id conforme esperado!");
            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao salvar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    /**
     * Metodo que faz o delete do banco de dados utilizando o paramentro do
     * cliente para poder estoura erro caso nao consiga executar o processo
     *
     * @param cliente
     */
    @Override
    public void deletar(Cliente cliente) {
        try {
            String sql = "DELETE FROM cliente WHERE id = ?";

            conectar(sql);
            comando.setInt(1, cliente.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao deletar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    /**
     * Metodo que atualiza as informaçoes do banco buscando pelo ID do parametro
     * mostra mensagem de erro caso nao consiga atualizar.
     *
     * @param cliente
     */
    @Override
    public void atualizar(Cliente cliente) {
        try {
            String sql = "UPDATE cliente set rg = ?, nome = ?, telefone = ? "
                    + "WHERE id = ?";

            conectar(sql);
            comando.setString(1, cliente.getRg());
            comando.setString(2, cliente.getNome());
            comando.setString(3, cliente.getTelefone());
            comando.setInt(4, cliente.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao atualizar cliente no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    /**
     * Metodo que busca a lista completa de dados dos clientes informa mensagem
     * de erro caso nao consiga executar a query
     *
     * @return listaClientes
     */
    @Override
    public List<Cliente> listar() {
        List<Cliente> listaClientes = new ArrayList<>();

        String sql = "SELECT * FROM cliente";

        try {
            conectar(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String rg = resultado.getString("rg");
                String nome = resultado.getString("nome");
                String telefone = resultado.getString("telefone");

                Cliente cliente = new Cliente(id, rg, nome, telefone);

                listaClientes.add(cliente);

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar os clientes do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (listaClientes);
    }

    /**
     * Metodo que procura especificamente pelo id informado pelo paramentro
     * informa mensagem de erro caso nao consiga executar a query
     *
     * @param id
     * @return cliente ou null
     */
    @Override
    public Cliente procurarPorId(int id) {
        String sql = "SELECT * FROM cliente WHERE id = ?";

        try {
            conectar(sql);
            comando.setInt(1, id);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                String rg = resultado.getString("rg");
                String nome = resultado.getString("nome");
                String telefone = resultado.getString("telefone");
                Cliente cliente = new Cliente(id, rg, nome, telefone);

                return cliente;

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar o cliente pelo id do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);
    }

    /**
     * Metodo que procura especificamente pelo rg informado pelo paramentro
     * informa mensagem de erro caso nao consiga executar a query
     *
     * @param rg
     * @return cliente
     */
    @Override
    public Cliente procurarPorRg(String rg) {
        String sql = "SELECT * FROM cliente WHERE rg = ?";

        try {
            conectar(sql);
            comando.setString(1, rg);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String telefone = resultado.getString("telefone");
                Cliente cliente = new Cliente(id, rg, nome, telefone);

                return cliente;

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar o cliente pelo rg do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);
    }

    /**
     * Metodo que busca a lista completa de dados dos clientes procurando pelo
     * rg informa mensagem de erro caso nao consiga executar a query
     *
     * @param rg
     * @return
     */
    @Override
    public List<Cliente> listarPorRg(String rg) {
        List<Cliente> listaClientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente WHERE rg LIKE ?";

        try {
            conectar(sql);
            comando.setString(1, "%" + rg + "%");
            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nomeX = resultado.getString("nome");
                String telefone = resultado.getString("telefone");
                Cliente cliente = new Cliente(id, rg, nomeX, telefone);

                listaClientes.add(cliente);

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar os clientes pelo nome do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
        return (listaClientes);
    }
}
