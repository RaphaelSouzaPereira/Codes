package daoBD;

/**
 *Classe para tratamento de erro caso de erro em alguma conexão ou execuçao de query no banco.
 * @author rapha
 */
public class BDException extends RuntimeException {

    public BDException(String s) {
        super(s);
    }

    public BDException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public BDException(Throwable throwable) {
        super(throwable);
    }
}
