/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoBD;

import dao.PetDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Pet;

/**
 *
 * @author rapha
 */
public class PetDaoBd implements PetDao {

    //Variaveis que fazem a conexao com o banco de dados e executam os comandos sql enviados ao banco e trazendo seus resultados.
    private Connection conexao;
    private PreparedStatement comando;

    /**
     * Metodo que pega uma conexao com o Banco utilizando o connection factory .
     *
     * @param sql
     * @return retorna a conexão com o banco ou estoura erro caso não consiga
     * fazer.
     * @throws SQLException
     */
    public Connection conectar(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql);
        return conexao;
    }

    /**
     * Metodo que conecta com o banco recebendo e pegando o id que está
     * vinculado a row.
     *
     * @param sql
     * @throws SQLException
     */
    public void conectarObtendoId(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
    }

    /**
     * Metodo que fecha a conexao caso ela continue aberta depois de alguma
     * execução retorna uma erro caso nao consiga encerrar
     */
    public void fecharConexao() {
        try {
            if (comando != null) {
                comando.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Erro ao encerrar a conexao");
            throw new BDException(ex);

        }
    }

    @Override
    public void salvar(Pet pet) {
        int id = 0;
        try {
            String sql = "INSERT INTO pet (nome, tipo, rg) "
                    + "VALUES (?,?,?)";

            //Foi criado um novo método conectar para obter o id
            conectarObtendoId(sql);
            comando.setString(1, pet.getNome());
            comando.setString(2, pet.getTipo());
            comando.setString(3, pet.getRg());
            comando.executeUpdate();
            //Obtém o resultSet para pegar o id
            ResultSet resultado = comando.getGeneratedKeys();
            if (resultado.next()) {
                //seta o id para o objeto
                id = resultado.getInt("id");
                pet.setId(id);
            } else {
                System.err.println("Erro de Sistema - Nao gerou o id conforme esperado!");
                throw new BDException("Nao gerou o id conforme esperado!");
            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao salvar pet no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public void deletar(Pet pet) {
        try {
            String sql = "DELETE FROM pet WHERE id = ?";

            conectar(sql);
            comando.setInt(1, pet.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao deletar pet no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public void atualizar(Pet pet) {
        try {
            String sql = "UPDATE pet set nome=?, tipo=?, rg=? "
                    + "WHERE id=?";

            conectar(sql);
            comando.setString(1, pet.getNome());
            comando.setString(2, pet.getTipo());
            comando.setString(3, pet.getRg());
            comando.setInt(4, pet.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao atualizar pet no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public List<Pet> listar() {
        List<Pet> listaPets = new ArrayList<>();

        String sql = "SELECT * FROM pet";

        try {
            conectar(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String tipo = resultado.getString("tipo");
                String rg = resultado.getString("rg");

                Pet pet = new Pet(id, nome, tipo, rg);

                listaPets.add(pet);

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar os Pets do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (listaPets);
    }

    @Override
    public Pet procurarPorId(int id) {
        String sql = "SELECT * FROM pet WHERE id = ?";

        try {
            conectar(sql);
            comando.setInt(1, id);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                String nome = resultado.getString("nome");
                String tipo = resultado.getString("tipo");
                String rg = resultado.getString("rg");
                Pet pet = new Pet(id, nome, tipo, rg);

                return pet;

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar o pet pelo id do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);
    }

}
