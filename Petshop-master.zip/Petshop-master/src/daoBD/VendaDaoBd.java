/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoBD;

import dao.VendaDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import model.Pet;
import model.Venda;

/**
 *
 * @author rapha
 */
public class VendaDaoBd implements VendaDao {

    //Variaveis que fazem a conexao com o banco de dados e executam os comandos sql enviados ao banco e trazendo seus resultados.
    private Connection conexao;
    private PreparedStatement comando;

    /**
     * Metodo que pega uma conexao com o Banco utilizando o connection factory .
     *
     * @param sql
     * @return retorna a conexão com o banco ou estoura erro caso não consiga
     * fazer.
     * @throws SQLException
     */
    public Connection conectar(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql);
        return conexao;
    }

    /**
     * Metodo que conecta com o banco recebendo e pegando o id que está
     * vinculado a row.
     *
     * @param sql
     * @throws SQLException
     */
    public void conectarObtendoId(String sql) throws SQLException {
        conexao = ConnectionFactory.getConnection();
        comando = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
    }

    /**
     * Metodo que fecha a conexao caso ela continue aberta depois de alguma
     * execução retorna uma erro caso nao consiga encerrar
     */
    public void fecharConexao() {
        try {
            if (comando != null) {
                comando.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Erro ao encerrar a conexao");
            throw new BDException(ex);

        }
    }

    @Override
    public void salvar(Venda venda) {
        int id = 0;
        try {
            String sql = "INSERT INTO venda (iddopet, iddoservico, diahora, valor, rgdocliente) "
                    + "VALUES (?,?,?,?,?)";

            //Foi criado um novo método conectar para obter o id
            conectarObtendoId(sql);
            comando.setInt(1, venda.getIdDoPet());
            comando.setInt(2, venda.getIdServico());
            Timestamp ts = Timestamp.valueOf(venda.getDiaHora());
            comando.setTimestamp(3, ts);
            comando.setDouble(4, venda.getValorTotalDaVenda());
            comando.setString(5, venda.getRgDoCliente());
            comando.executeUpdate();
            //Obtém o resultSet para pegar o id
            ResultSet resultado = comando.getGeneratedKeys();
            if (resultado.next()) {
                //seta o id para o objeto
                id = resultado.getInt("id");
                venda.setId(id);
            } else {
                System.err.println("Erro de Sistema - Nao gerou o id conforme esperado!");
                throw new BDException("Nao gerou o id conforme esperado!");
            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao salvar a Venda no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public void deletar(Venda venda) {
        try {
            String sql = "DELETE FROM venda WHERE id = ?";

            conectar(sql);
            comando.setInt(1, venda.getId());
            comando.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao deletar Venda no Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }
    }

    @Override
    public List<Venda> listar() {
        List<Venda> listaVendas = new ArrayList<>();

        String sql = "SELECT * FROM venda";

        try {
            conectar(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {
                int id = resultado.getInt("id");
                int idDoPet = resultado.getInt("iddopet");
                int idDoServico = resultado.getInt("iddoservico");
                Timestamp ts = resultado.getTimestamp("diahora");
                LocalDateTime diaHora = ts.toLocalDateTime();
                Double valor = resultado.getDouble("valor");
                String rgDoCliente = resultado.getString("rgdocliente");

                Venda venda = new Venda(id, idDoPet, idDoServico, diaHora, valor, rgDoCliente);

                listaVendas.add(venda);

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar as vendas do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (listaVendas);
    }

    @Override
    public Venda procurarPorId(int id) {
        String sql = "SELECT * FROM venda WHERE id = ?";

        try {
            conectar(sql);
            comando.setInt(1, id);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                int idDoPet = resultado.getInt("iddopet");
                int idDoServico = resultado.getInt("iddoservico");
                Timestamp ts = resultado.getTimestamp("diahora");
                LocalDateTime diaHora = ts.toLocalDateTime();
                Double valor = resultado.getDouble("valor");
                String rgDoCliente = resultado.getString("rgdocliente");

                Venda venda = new Venda(id, idDoPet, idDoServico, diaHora, valor, rgDoCliente);

                return venda;

            }

        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar a venda pelo id do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);
    }

    @Override
    public Double valorTotalDaVenda(int idDoPet, LocalDateTime diaHora, String rgDoCliente) {
        String sql = "SELECT SUM(valor) as total FROM venda WHERE iddopet = ? "
                + "AND diahora = ? "
                + "AND rgdocliente = ?";
                

        try {
            conectar(sql);
            comando.setInt(1, idDoPet);
            Timestamp ts = Timestamp.valueOf(diaHora);
            comando.setTimestamp(2, ts);
            comando.setString(3, rgDoCliente);
            ResultSet resultado = comando.executeQuery();
            if (resultado.next()) {
                Double valor = resultado.getDouble("total");
                return valor;
            }
        } catch (SQLException ex) {
            System.err.println("Erro de Sistema - Problema ao buscar as vendas do Banco de Dados!");
            throw new BDException(ex);
        } finally {
            fecharConexao();
        }

        return (null);

    }

}
