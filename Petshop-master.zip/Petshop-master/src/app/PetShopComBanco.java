/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import java.util.InputMismatchException;
import util.Console;
import view.ClienteUI;
import view.PetUI;
import view.ServicoUI;
import view.UIUtil;
import view.VendaUI;

/**
 *Clase main que executa menu principal e fecha o serviço
 * @author rapha
 */
public class PetShopComBanco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menu();
    }

    public static void menu() {

        int opcao = -1;

        do {
            try {
                System.out.println("Escolha uma opção do menu:"
                        + "\n1- para menu Cliente."
                        + "\n2- para menu Pets."
                        + "\n3- para menu Serviços."
                        + "\n4- para menu Venda."
                        + "\n5- para menu Relatórios(Não implementado)."
                        + "\n0- para fechar o sistema.");

                switch (opcao = Console.scanInt("Digite sua opção:")) {
                    case 1:
                        new ClienteUI().menu();
                        break;
                    case 2:
                        new PetUI().menu();
                        break;
                    case 3:
                        new ServicoUI().menu();
                        break;
                    case 4:
                        new VendaUI().menu();
                        break;
                    case 5:
                        //new RelatorioUI().menu();
                        break;
                    case 0:
                        opcao = 0;
                        break;
                    default:
                        System.out.println("Escolheu uma opção inválida");

                }
            } catch (InputMismatchException ex) {
                UIUtil.mostrarErro("Somente numeros sao permitidos!");
            }

        } while (opcao != 0);
        System.out.println("Você saiu do sistema.");
        System.exit(0);
    }
}
