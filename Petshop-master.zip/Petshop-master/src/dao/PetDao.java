/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Pet;

/**
 * Classe de interface para o PetDaoBd
 *
 * @author rapha
 */
public interface PetDao {

    public void salvar(Pet pet);

    public void deletar(Pet pet);

    public void atualizar(Pet pet);

    public List<Pet> listar();

    public Pet procurarPorId(int id);

}
