/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.time.LocalDateTime;
import java.util.List;
import model.Venda;

/**
 * Classe de interface para o VendaDaoBd
 *
 * @author rapha
 */
public interface VendaDao {

    public void salvar(Venda venda);

    public void deletar(Venda venda);

    public List<Venda> listar();

    public Venda procurarPorId(int id);

    public Double valorTotalDaVenda(int idDoPet, LocalDateTime diaHora, String rgDoCliente);
}
