/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Cliente;

/**
 * Classe de interface para o ClienteDaoBd
 *
 * @author rapha
 */
public interface ClienteDao {

    public void salvar(Cliente cliente);

    public void deletar(Cliente cliente);

    public void atualizar(Cliente cliente);

    public List<Cliente> listar();

    public Cliente procurarPorId(int id);

    //Adicionado
    public Cliente procurarPorRg(String rg);

    public List<Cliente> listarPorRg(String rg);
}
