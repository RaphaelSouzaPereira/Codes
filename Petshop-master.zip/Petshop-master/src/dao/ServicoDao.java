/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Servico;

/**
 * Classe de interface para o ServicoDaoBd
 *
 * @author rapha
 */
public interface ServicoDao {

    public void salvar(Servico servico);

    public void deletar(Servico servico);

    public void atualizar(Servico servico);

    public List<Servico> listar();

    public Servico procurarPorId(int id);
}
