package view;

import app.PetShopComBanco;
import dao.PetDao;
import dao.ServicoDao;
import dao.VendaDao;
import daoBD.PetDaoBd;
import daoBD.ServicoDaoBd;
import daoBD.VendaDaoBd;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import util.Console;
import util.DateUtil;
import java.util.InputMismatchException;
import java.util.List;
import model.Pet;
import model.Servico;
import model.Venda;
import view.menu.VendaMenu;

/**
 *
 * @author lhries
 */
public class VendaUI {

    private VendaDao vendaDao;

    public VendaUI() {
        vendaDao = new VendaDaoBd();
    }

    public void menu() {
        int opcao = -1;
        do {
            try {
                System.out.println(VendaMenu.getOpcoes());
                opcao = Console.scanInt("Digite sua opção:");
                switch (opcao) {
                    case VendaMenu.OP_CADASTRAR:
                        cadastrarVenda();
                        break;
                    case VendaMenu.OP_DELETAR:
                        deletarVenda();
                        break;
                    case VendaMenu.OP_LISTAR:
                        mostrarListaVendas();
                        break;
                    case VendaMenu.OP_TOTALDAVENDA:
                        mostrarCustoTotal();
                        break;
                    case VendaMenu.OP_SAIR:
                        System.out.println("Finalizando a aplicacao..");
                        PetShopComBanco.menu();
                        break;
                    default:
                        System.out.println("Opção inválida..");
                }
            } catch (InputMismatchException ex) {
                UIUtil.mostrarErro("Somente numeros são permitidos!");
            }

        } while (opcao != VendaMenu.OP_SAIR);
    }

    private void cadastrarVenda() {

        System.out.println("Cadastrando uma venda:");
        mostrarListaPets();
        int idDoPet = Console.scanInt("Selecione um dos Pets pelo ID: ");
        PetDao petDao = new PetDaoBd();
        Pet pet = petDao.procurarPorId(idDoPet);
        mostrarListaServicos();
        int idDoServico = Console.scanInt("Digite o ID do serviço prestado: ");
        ServicoDao servicoDao = new ServicoDaoBd();
        Servico servico = servicoDao.procurarPorId(idDoServico);
        String dataHorario = Console.scanString("Digite data e hora do atendimento (dd/MM/yyyy HH:mm): ");
        LocalDateTime diaHora = DateUtil.stringToDateTime(dataHorario);
        vendaDao.salvar(new Venda(servico.getId(), pet.getId(), diaHora, servico.getPreco(), pet.getRg()));
        petDao = null;
        pet = null;
        servicoDao = null;
        servico = null;
        System.out.println("Venda cadastrado com sucesso!");
    }

    public void mostrarListaVendas() {
        List<Venda> listaVendas = vendaDao.listar();
        this.mostrarVendas(listaVendas);
    }

    private void deletarVenda() {
        mostrarListaVendas();
        int id = Console.scanInt("Digite o id da venda a ser deletado: ");
        Venda v = vendaDao.procurarPorId(id);
        this.mostrarVenda(v);
        if (UIUtil.getConfirmacao("Realmente deseja excluir essa venda?")) {
            vendaDao.deletar(v);
            System.out.println("Venda deletado com sucesso!");
        } else {
            System.out.println("Operacao cancelada!");
        }
    }

    private void mostrarVenda(Venda v) {
        System.out.println("-----------------------------");
        System.out.println("Venda");
        System.out.println("ID: " + v.getId());
        System.out.println("ID DO SERVIÇO: " + v.getIdServico());
        System.out.println("VALOR: " + v.getValorTotalDaVenda());
        System.out.println("DATA: "
                + DateUtil.dateTimeToString(v.getDiaHora()));
        System.out.println("ID DO PET: " + v.getIdDoPet());
        System.out.println("RG DO DONO: " + v.getRgDoCliente());
        System.out.println("-----------------------------");
    }

    private void mostrarVendas(List<Venda> listaVendas) {
        if (listaVendas.isEmpty()) {
            System.out.println("Vendas nao encontradas!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-3s", "ID") + "\t"
                    + String.format("%-15s", "|ID DO SERVIÇO") + "\t"
                    + String.format("%-7s", "|VALOR") + "\t"
                    + String.format("%-20s", "|DATA") + "\t"
                    + String.format("%-10s", "|ID DO PET") + "\t"
                    + String.format("%-15s", "|RG DO DONO") + "\t");

            for (Venda venda : listaVendas) {
                System.out.println(String.format("%-3s", venda.getId()) + "\t"
                        + String.format("%-15s", "|" + venda.getIdServico()) + "\t"
                        + String.format("%-7s", "|" + venda.getValorTotalDaVenda()) + "\t"
                        + String.format("%-20s", "|" + DateUtil.dateTimeToString(venda.getDiaHora()) + "\t"
                                + String.format("%-10s", "|" + venda.getIdDoPet()) + "\t"
                                + String.format("%-15s", "|" + venda.getRgDoCliente())));
            }
        }
    }

    private void mostrarCustoTotal() {
        mostrarListaPets();
        int idDoPet = Console.scanInt("Selecione um dos Pets pelo ID: ");
        PetDao petDao = new PetDaoBd();
        Pet pet = petDao.procurarPorId(idDoPet);
        LocalDateTime data = DateUtil.stringToDateTime(Console.scanString("Digite a data da venda: "));
        Double valorTotalDoServico = vendaDao.valorTotalDaVenda(pet.getId(), data, pet.getRg());
        System.out.println("Total de Gasto do cliente nestas vendas feita no " + DateUtil.dateTimeToString(data) + " é de " + valorTotalDoServico);
    }

    public void mostrarListaPets() {
        PetDao petDao = new PetDaoBd();
        List<Pet> listaPets = petDao.listar();
        this.mostrarPets(listaPets);
    }

    private void mostrarPets(List<Pet> listaPets) {
        if (listaPets.isEmpty()) {
            System.out.println("Pet nao encontrados!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-3s", "ID") + "\t"
                    + String.format("%-10s", "|NOME") + "\t"
                    + String.format("%-20s", "|TIPO") + "\t"
                    + String.format("%-12s", "|RG"));
            for (Pet pet : listaPets) {
                System.out.println(String.format("%-3s", pet.getId()) + "\t"
                        + String.format("%-10s", "|" + pet.getNome()) + "\t"
                        + String.format("%-20s", "|" + pet.getTipo()) + "\t"
                        + String.format("%-12s", "|" + pet.getRg()));
            }
        }
    }

    public void mostrarListaServicos() {
        ServicoDao servicoDao = new ServicoDaoBd();
        List<Servico> listaServico = servicoDao.listar();
        this.mostrarServicos(listaServico);
    }

    private void mostrarServicos(List<Servico> listaServicos) {
        if (listaServicos.isEmpty()) {
            System.out.println("Servico nao encontrados!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-3s", "ID") + "\t"
                    + String.format("%-10s", "|NOME") + "\t"
                    + String.format("%-20s", "|TIPO") + "\t"
                    + String.format("%-10s", "|PREÇO"));
            for (Servico servico : listaServicos) {
                System.out.println(String.format("%-3s", servico.getId()) + "\t"
                        + String.format("%-10s", "|" + servico.getNome()) + "\t"
                        + String.format("%-20s", "|" + servico.getTipoDeAtendimento()) + "\t"
                        + String.format("%-10s", "|" + servico.getPreco()));
            }
        }
    }

}
