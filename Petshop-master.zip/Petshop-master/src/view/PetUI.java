package view;

import app.PetShopComBanco;
import dao.ClienteDao;
import dao.PetDao;
import daoBD.ClienteDaoBd;
import daoBD.PetDaoBd;
import util.Console;
import java.util.InputMismatchException;
import java.util.List;
import model.Cliente;
import model.Pet;
import view.menu.PetMenu;

/**
 *
 * @author lhries
 */
public class PetUI {

    private PetDao petDao;

    public PetUI() {
        petDao = new PetDaoBd();
    }

    public void menu() {
        int opcao = -1;
        do {
            try {
                System.out.println(PetMenu.getOpcoes());
                opcao = Console.scanInt("Digite sua opção:");
                switch (opcao) {
                    case PetMenu.OP_CADASTRAR:
                        cadastrarPet();
                        break;
                    case PetMenu.OP_DELETAR:
                        deletarPet();
                        break;
                    case PetMenu.OP_ATUALIZAR:
                        atualizarPet();
                        break;
                    case PetMenu.OP_LISTAR:
                        mostrarListaPets();
                        break;
                    case PetMenu.OP_SAIR:
                        System.out.println("Finalizando a aplicacao..");
                        PetShopComBanco.menu();
                        break;
                    default:
                        System.out.println("Opção inválida..");
                }
            } catch (InputMismatchException ex) {
                UIUtil.mostrarErro("Somente numeros sao permitidos!");
            }

        } while (opcao != PetMenu.OP_SAIR);
    }

    private void cadastrarPet() {
        String nome = Console.scanString("Nome: ");
        String tipo = Console.scanString("Tipo: ");
        System.out.println("Escolha um entre os Clientes");
        mostrarListaCliente();
        String rg = Console.scanString("Digite o RG de um dos donos da lista:");
        petDao.salvar(new Pet(nome, tipo, rg));
        System.out.println("Pet " + nome + " cadastrado com sucesso!");
    }

    public void mostrarListaPets() {
        List<Pet> listaPets = petDao.listar();
        this.mostrarPets(listaPets);
    }

    private void deletarPet() {
        mostrarListaPets();
        int id = Console.scanInt("Digite o id do pet a ser deletado: ");
        Pet p = petDao.procurarPorId(id);
        this.mostrarPet(p);
        if (UIUtil.getConfirmacao("Realmente deseja excluir esse pet?")) {
            petDao.deletar(p);
            System.out.println("Pet deletado com sucesso!");
        } else {
            System.out.println("Operacao cancelada!");
        }
    }

    private void atualizarPet() {
        mostrarListaPets();
        int id = Console.scanInt("Digite o id do pet a ser alterado: ");
        Pet p = petDao.procurarPorId(id);
        if(p == null){
            System.out.println("Pet nao encontrado");
            atualizarPet();
        }else{
        this.mostrarPet(p);
        System.out.println("Digite os dados do pet que quer alterar [Vazio caso nao queira]");
        String nome = Console.scanString("Nome: ");
        String tipo = Console.scanString("Tipo: ");
        System.out.println("Escolha um entre os Clientes");
        mostrarListaCliente();
        String rg = Console.scanString("Digite o RG de um dos donos da lista:");
        if (!nome.isEmpty()) {
            p.setNome(nome);
        }
        if (!tipo.isEmpty()) {
            p.setTipo(tipo);
        }
        if (!rg.isEmpty()) {
            p.setRg(rg);
        }

        petDao.atualizar(p);
        System.out.println("Pet " + nome + " atualizado com sucesso!");
        }
    }

    private void mostrarPet(Pet p) {
        System.out.println("-----------------------------");
        System.out.println("Pet");
        System.out.println("Nome: " + p.getNome());
        System.out.println("Tipo: " + p.getTipo());
        System.out.println("RG: " + p.getRg());
        System.out.println("-----------------------------");
    }

    private void mostrarPets(List<Pet> listaPets) {
        if (listaPets.isEmpty()) {
            System.out.println("Pet nao encontrados!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-3s", "ID") + "\t"
                    + String.format("%-10s", "|NOME") + "\t"
                    + String.format("%-20s", "|TIPO") + "\t"
                    + String.format("%-12s", "|RG"));
            for (Pet pet : listaPets) {
                System.out.println(String.format("%-3s", pet.getId()) + "\t"
                        + String.format("%-10s", "|" + pet.getNome()) + "\t"
                        + String.format("%-20s", "|" + pet.getTipo()) + "\t"
                        + String.format("%-12s", "|" + pet.getRg()));
            }
        }
    }

    public void mostrarListaCliente() {
        ClienteDao clienteDao = new ClienteDaoBd();
        List<Cliente> listaClientes = clienteDao.listar();
        this.mostrarClientes(listaClientes);
    }

    private void mostrarClientes(List<Cliente> listaClientes) {
        if (listaClientes.isEmpty()) {
            System.out.println("Clientes nao encontrados!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-10s", "RG") + "\t"
                    + String.format("%-20s", "|NOME") + "\t"
                    + String.format("%-20s", "|TELEFONE"));
            for (Cliente cliente : listaClientes) {
                System.out.println(String.format("%-10s", cliente.getRg()) + "\t"
                        + String.format("%-20s", "|" + cliente.getNome()) + "\t"
                        + String.format("%-20s", "|" + cliente.getTelefone()));
            }
        }
    }

}
