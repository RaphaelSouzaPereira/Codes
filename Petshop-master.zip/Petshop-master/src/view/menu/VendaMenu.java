package view.menu;

public class VendaMenu {

    public static final int OP_CADASTRAR = 1;
    public static final int OP_DELETAR = 2;
    public static final int OP_LISTAR = 3;
    public static final int OP_TOTALDAVENDA = 4;
    public static final int OP_SAIR = 0;

    public static String getOpcoes() {
        return ("\n--------------------------------------\n"
                + "1- Cadastrar Venda\n"
                + "2- Deletar Venda\n"
                + "3- Listar Vendas\n"
                + "4- Total de uma venda\n"
                + "0- Sair"
                + "\n--------------------------------------");
    }
}
