package view.menu;

public class ServicoMenu {

    public static final int OP_CADASTRAR = 1;
    public static final int OP_DELETAR = 2;
    public static final int OP_ATUALIZAR = 3;
    public static final int OP_LISTAR = 4;
    public static final int OP_SAIR = 0;

    public static String getOpcoes() {
        return ("\n--------------------------------------\n"
                + "1- Cadastrar Serviço\n"
                + "2- Deletar Serviço\n"
                + "3- Atualizar dados do Serviço\n"
                + "4- Listar Serviço\n"
                + "0- Sair"
                + "\n--------------------------------------");
    }
}
