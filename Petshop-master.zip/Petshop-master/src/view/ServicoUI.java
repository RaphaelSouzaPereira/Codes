package view;

import app.PetShopComBanco;
import dao.ServicoDao;
import daoBD.ServicoDaoBd;
import util.Console;
import view.menu.ClienteMenu;
import java.util.InputMismatchException;
import java.util.List;
import model.Servico;
import view.menu.ServicoMenu;

/**
 *
 * @author lhries
 */
public class ServicoUI {

    private ServicoDao servicoDao;

    public ServicoUI() {
        servicoDao = new ServicoDaoBd();
    }

    public void menu() {
        int opcao = -1;
        do {
            try {
                System.out.println(ServicoMenu.getOpcoes());
                opcao = Console.scanInt("Digite sua opção:");
                switch (opcao) {
                    case ServicoMenu.OP_CADASTRAR:
                        cadastrarServico();
                        break;
                    case ServicoMenu.OP_DELETAR:
                        deletarServico();
                        break;
                    case ServicoMenu.OP_ATUALIZAR:
                        atualizarServico();
                        break;
                    case ServicoMenu.OP_LISTAR:
                        mostrarListaServicos();
                        break;
                    case ServicoMenu.OP_SAIR:
                        System.out.println("Finalizando a aplicacao..");
                        PetShopComBanco.menu();
                        break;
                    default:
                        System.out.println("Opção inválida..");
                }
            } catch (InputMismatchException ex) {
                UIUtil.mostrarErro("Somente numeros sao permitidos!");
            }

        } while (opcao != ClienteMenu.OP_SAIR);
    }

    private void cadastrarServico() {
        String nome = Console.scanString("Nome: ");
        String tipo = Console.scanString("Tipo de Atendimento: ");
        Double preco = Console.scanDouble("Preço: ");
        servicoDao.salvar(new Servico(nome, tipo, preco));
        System.out.println("Serviço " + nome + " cadastrado com sucesso!");
    }

    public void mostrarListaServicos() {
        List<Servico> listaServico = servicoDao.listar();
        this.mostrarServicos(listaServico);
    }

    private void deletarServico() {
        mostrarListaServicos();
        int id = Console.scanInt("Digite o id do serviço a ser deletado: ");
        Servico serv = servicoDao.procurarPorId(id);
        this.mostrarServico(serv);
        if (UIUtil.getConfirmacao("Realmente deseja excluir esse serviço?")) {
            servicoDao.deletar(serv);
            System.out.println("Serviço deletado com sucesso!");
        } else {
            System.out.println("Operacao cancelada!");
        }
    }

    private void atualizarServico() {
        mostrarListaServicos();
        int id = Console.scanInt("Digite o id do serviço a ser alterado: ");
        Servico serv = servicoDao.procurarPorId(id);
        this.mostrarServico(serv);
        System.out.println("Digite os dados do serviço que quer alterar [Vazio caso nao queira]");
        String nome = Console.scanString("Nome: ");
        String tipo = Console.scanString("Tipo de Atendimento: ");
        Double preco = 0.0;
        preco = Console.scanDouble("Preço(digite 0 caso nao queira mudar): ");
        if (!nome.isEmpty()) {
            serv.setNome(nome);
        }
        if (!tipo.isEmpty()) {
            serv.setTipoDeAtendimento(tipo);
        }
        if (preco > 0.0 || preco != null) {
            serv.setPreco(preco);
        }

        servicoDao.atualizar(serv);
        System.out.println("Serviço " + nome + " atualizado com sucesso!");

    }

    private void mostrarServico(Servico servico) {
        System.out.println("-----------------------------");
        System.out.println("Servico");
        System.out.println("ID: " + servico.getId());
        System.out.println("Nome: " + servico.getNome());
        System.out.println("Tipo: " + servico.getTipoDeAtendimento());
        System.out.println("Preço: " + servico.getPreco());
        System.out.println("-----------------------------");
    }

    private void mostrarServicos(List<Servico> listaServicos) {
        if (listaServicos.isEmpty()) {
            System.out.println("Servico nao encontrados!");
        } else {
            System.out.println("-----------------------------\n");
            System.out.println(String.format("%-3s", "ID") + "\t"
                    + String.format("%-10s", "|NOME") + "\t"
                    + String.format("%-20s", "|TIPO") + "\t"
                    + String.format("%-10s", "|PREÇO"));
            for (Servico servico : listaServicos) {
                System.out.println(String.format("%-3s", servico.getId()) + "\t"
                        + String.format("%-10s", "|" + servico.getNome()) + "\t"
                        + String.format("%-20s", "|" + servico.getTipoDeAtendimento()) + "\t"
                        + String.format("%-10s", "|" + servico.getPreco()));
            }
        }
    }
}
