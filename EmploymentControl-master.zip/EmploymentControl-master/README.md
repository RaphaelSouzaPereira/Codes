# IBMEmploymentControlAPP
IBM Employment Control APP

Aplicativo para gestão de vagas na IBM Porto Alegre.

Desenvolvido pelos TryCatcher's:
* Diego
* Fábio
* Leandro
* Pedro
* Priscila
* Raphael
* Renan
