/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacao;

import Model.MoedaModel;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Hashtable;
import util.ConsoleUtil;
import util.DateUtil;

/**
 * `Classe Objeto do conversor de moedas
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class ConversorApplicacao {

    /*HashTable com todas as moedas guardadas como objetos e ArrayList
    com codgo das moedas para listar no menu*/
    Hashtable<String, MoedaModel> moedas;
    ArrayList<String> nomeDasMoedas;

    /**
     * Construtor do objeto Conversor
     *
     * @param moedas HashTable criada na leitura do arquivo
     * @param nomeDasMoedas ArrayList com nome das moedas pego do arquivo
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public ConversorApplicacao(Hashtable<String, MoedaModel> moedas, ArrayList<String> nomeDasMoedas) {
        this.moedas = moedas;
        this.nomeDasMoedas = nomeDasMoedas;
    }

    /**
     * Funcao principal que trabalha busca os dados do console insere nas
     * funcoes de controle e printa o resultado na tela.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public void converteMoeda() {
        String listaMoedas = "Lista das moedas \n";
        for (int i = 1; i < this.nomeDasMoedas.size(); i++) {
            listaMoedas += "|" + this.nomeDasMoedas.get(i) + "|";
            if (i > 0) {
                if (i % 10 == 0) {
                    listaMoedas += "\n";
                }
            }
        }
        try {
            System.out.println(listaMoedas);
            System.out.println("-----------------------------------------");
            ConsoleUtil console = new ConsoleUtil();
            String from = console.scanString("Converter: ").toUpperCase();
            String to = console.scanString("Para: ").toUpperCase();
            validaMoedas(from, to);
            Number value = null;
            value = validaValue(console.scanDouble("Quantidade a converter: "));
            String quotation = DateUtil.dateToString(atualizaData(DateUtil.stringToDate(console.scanString("Data da cotação(DD/MM/AAAA): "))));
            BigDecimal valorFinal = currencyQuotation(from, to, value, quotation).setScale(2, RoundingMode.HALF_EVEN);
            System.out.println(resultadoFinal(valorFinal, quotation, from, to, value));

        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }

    /**
     * Classe que faz os calculos e valida os dados passados.
     *
     * @param from moeda a converter
     * @param to moeda para o qual sera convertida
     * @param value valor que será convertido
     * @param quotation data da cotação da conversão
     * @return valorCalculado
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal currencyQuotation(String from, String to, Number value, String quotation) throws IllegalArgumentException {
        BigDecimal valorCalculado = null;
        MoedaModel moeda1 = this.moedas.get(from);
        MoedaModel moeda2 = this.moedas.get(to);
        LocalDate data = DateUtil.stringToDate(quotation);
        validaDataTabela(data, moeda1.getData());
        valorCalculado = new BigDecimal(calculaValor(moeda1, moeda2, value).doubleValue());

        return valorCalculado;
    }

    /**
     * Função que confere a data se está em um final de semana e para para o
     * próximo dia útil
     *
     * @param data para ser conferida
     * @return dataValida
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public LocalDate atualizaData(LocalDate data) {
        LocalDate dataValida = data;
        if (data.getDayOfWeek().getValue() == 6) {
            dataValida = data.plusDays(2);
        } else if (data.getDayOfWeek().getValue() == 7) {
            dataValida = data.plusDays(1);
        }
        return dataValida;

    }

    /**
     * Função para validar se data informada existe condiz com as atualizações
     * da tabela de moedas.
     *
     * @param data
     * @param dataMoeda
     * @throws IllegalArgumentException
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    private void validaDataTabela(LocalDate data, LocalDate dataMoeda) throws IllegalArgumentException {
        if (!DateUtil.dateToString(data).equals(DateUtil.dateToString(dataMoeda))) {
            throw new IllegalArgumentException("Tabela nao contem dados do dia informado " + DateUtil.dateToString(data));
        }

    }

    /**
     * Função que faz o calculdo de acordo com a regra do tipo de moeda e se for
     *
     * @param moeda1 moeda a converter
     * @param moeda2 para o qual sera convertida
     * @param valor valor a ser convertido
     * @return valor total convertido para nova moeda
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public Number calculaValor(MoedaModel moeda1, MoedaModel moeda2, Number valor) {
        if (moeda2.getMoeda().equals("BRL")) {
            valor = valor.doubleValue() * moeda1.getTaxaCompra().doubleValue();
        } else if (moeda1.getMoeda().equals("USD")) {
            if (moeda1.getTipo().equals("A")) {
                valor = valor.doubleValue() / moeda2.getParidadeVenda().doubleValue();
            } else {
                valor = valor.doubleValue() * moeda2.getParidadeVenda().doubleValue();
            }
        } else if (moeda1.getMoeda().equals("BRL")) {
            valor = valor.doubleValue() / moeda2.getTaxaVenda().doubleValue();
        } else if (moeda2.getMoeda().equals("USD")) {
            if (moeda1.getTipo().equals("A")) {
                valor = valor.doubleValue() / moeda1.getParidadeCompra().doubleValue();
            } else {
                valor = valor.doubleValue() * moeda1.getParidadeCompra().doubleValue();
            }
        }
        return valor;
    }

    /**
     * Função para validar moedas se estão são BRL ou USD em qualquer uma das
     * moedas 1 ou 2 pois dados do csv não contem valores de conversão entre
     * moedas diferentes destar duas em algum ponto exemplo: EUR para ARS,
     * também contém validações se tenta converter moedas ou se alguma das
     * moedas passadas são inválidas
     *
     * @param moeda1 a se converter
     * @param moeda2 a ser convertida
     * @throws IllegalArgumentException
     * @throws NullPointerException
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    private void validaMoedas(String moeda1, String moeda2) throws IllegalArgumentException, NullPointerException {
        if (moeda1.equals(moeda2)) {
            throw new IllegalArgumentException("Nao pode converter moedas iguais.");
        } else if (moedas.get(moeda1) == null || moedas.get(moeda2) == null) {
            throw new NullPointerException("Moeda nao consta na lista");
        } else if (!moeda1.equals("USD")
                && !moeda1.equals("BRL")
                && !moeda2.equals("USD")
                && !moeda2.equals("BRL")) {
            throw new IllegalArgumentException("Não contém os valores para fazer a conversão");
        }
    }

    /**
     * Funçao para validar se valor é positivo
     *
     * @param scanDouble valor para ser validado
     * @return scanDouble valor se positivo ou igual a zero
     * @throws IllegalArgumentException se o valor for menos que zero
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public Number validaValue(double scanDouble) throws IllegalArgumentException {
        if (scanDouble < 0) {
            throw new IllegalArgumentException("Não é possível digitar valor negativo.");
        }
        return scanDouble;
    }

    /**
     * Metodo monta tela final
     *
     * @param valorFinal resultado final
     * @param quotation data
     * @param from moeda a converter
     * @param to moeda que ira ser convertida
     * @param value valor a ser convertido
     * @return tela para printar
     */
    private String resultadoFinal(BigDecimal valorFinal, String quotation, String from, String to, Number value) {
        MoedaModel moeda1 = this.moedas.get(from);
        MoedaModel moeda2 = this.moedas.get(to);
        BigDecimal valor1 = currencyQuotation(from, to, 1, quotation).setScale(6, RoundingMode.HALF_EVEN);
        BigDecimal valor2 = currencyQuotation(to, from, 1, quotation).setScale(6, RoundingMode.HALF_EVEN);

        String tela = "-----------------------------------------"
                + "\nConversão de: " + moeda1.getMoeda() + " (" + moeda1.getCodMoeda() + ")"
                + "\nValor a converter: " + value.doubleValue()
                + "\nPara: " + moeda2.getMoeda() + " (" + moeda2.getCodMoeda() + ")"
                + "\nResultado da conversão: " + valorFinal.doubleValue()
                + "\nData cotação utilizada: " + quotation
                + "\nTaxa: "
                + "\n 1 " + moeda1.getMoeda() + " (" + moeda1.getCodMoeda() + ") = "
                + valor1 + " "
                + moeda2.getMoeda() + " (" + moeda2.getCodMoeda() + ")"
                + "\n 1 " + moeda2.getMoeda() + " (" + moeda2.getCodMoeda() + ") = "
                + valor2 + " "
                + moeda1.getMoeda() + " (" + moeda1.getCodMoeda() + ")"
                + "\n-----------------------------------------";
        return tela;
    }

}
