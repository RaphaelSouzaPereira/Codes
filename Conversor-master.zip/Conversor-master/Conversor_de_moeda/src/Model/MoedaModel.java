/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Classe Objeto MoedaModel com as informações de cada uma das moedas
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class MoedaModel {

    LocalDate data;
    String codMoeda;
    String tipo;
    String moeda;
    BigDecimal taxaCompra;
    BigDecimal taxaVenda;
    BigDecimal paridadeCompra;
    BigDecimal paridadeVenda;

    /**
     * Contrutor da classe
     *
     * @param data do documento e dos dados da moeda
     * @param codMoeda codigo da moeda
     * @param tipo qual é o tipo da moeda
     * @param moeda qual o nome da moeda
     * @param taxaCompra valor de compra por real
     * @param taxaVenda valor de venda por real
     * @param paridadeCompra valor de compra dolar
     * @param paridadeVenda valor de venda dolar
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public MoedaModel(LocalDate data, String codMoeda, String tipo, String moeda, BigDecimal taxaCompra, BigDecimal taxaVenda, BigDecimal paridadeCompra, BigDecimal paridadeVenda) {
        this.data = data;
        this.codMoeda = codMoeda;
        this.tipo = tipo;
        this.moeda = moeda;
        this.taxaCompra = taxaCompra;
        this.taxaVenda = taxaVenda;
        this.paridadeCompra = paridadeCompra;
        this.paridadeVenda = paridadeVenda;
    }
    
    /**
     * Metodo get Data
     * @return data
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public LocalDate getData() {
        return data;
    }
    
    /**
     * Metodo get codigo da moeda
     * @return codMoeda
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public String getCodMoeda() {
        return codMoeda;
    }
    
    /**
     * Metodo get tipo de moeda
     * @return tipo
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public String getTipo() {
        return tipo;
    }
    
    /**
     * Metodo get nome da moeda
     * @return moeda
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public String getMoeda() {
        return moeda;
    }
    
    /**
     * Metodo get Taxa de compra 
     * @return taxaCompra
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal getTaxaCompra() {
        return taxaCompra;
    }
    
    /**
     * Metodo get Taxa de venda
     * @return taxaVenda
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal getTaxaVenda() {
        return taxaVenda;
    }
    
    /**
     * Metodo get Paridade de compra
     * @return paridadedeCompra
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal getParidadeCompra() {
        return paridadeCompra;
    }
    
    /**
     * Metodo get ParidadedeVenda
     * @return paridadedevenda
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal getParidadeVenda() {
        return paridadeVenda;
    }

}
