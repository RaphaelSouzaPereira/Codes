/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Aplicacao.ConversorApplicacao;
import Model.MoedaModel;
import util.LeitorUtil;
import java.util.ArrayList;
import java.util.Hashtable;
import util.ConsoleUtil;

/**
 * Classe main com menu
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class ConversorDeMoeda {

    /**
     * Metodo main
     *
     * @param args the command line arguments
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static void main(String[] args) {

        Hashtable<String, MoedaModel> moedas = new Hashtable<String, MoedaModel>();
        ArrayList<String> nomeDasMoedas = new ArrayList<String>();
        LeitorUtil csv = new LeitorUtil();
        csv.leArquivo(moedas, nomeDasMoedas);
        ConversorApplicacao conversor = new ConversorApplicacao(moedas, nomeDasMoedas);
        int exit = 0;
        do {
            switch (menu()) {
                case '1':
                    conversor.converteMoeda();
                    break;
                case '2':
                    exit = 2;
                    break;
                default:
                    System.out.println("!!!Escolheu uma opção inválida!!!\n-----------------------------------------");
                    break;
            }
        } while (exit != 2);
        System.out.println("Você saiu do sistema.");
        moedas = null;
        nomeDasMoedas = null;
        csv = null;
        conversor = null;
        System.exit(0);

    }

    /**
     * Função menu para pegar a opção selecionada
     *
     * @return opcao escolhida
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    private static char menu() {
        ConsoleUtil console = new ConsoleUtil();
        char opcao;
        opcao = console.scanChar("Escolha uma opção do menu:"
                + "\n1 - para fazer intercambio de moeda"
                + "\n2 - para fechar o sistema."
                + "\n-----------------------------------------"
                + "\nSelectione uma das opções: ");
        System.out.println("-----------------------------------------");
        console = null;
        return opcao;
    }

}
