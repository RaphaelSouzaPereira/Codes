package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

/**
 * Classe com funções para converter String to LocalDate e LocalDate to String
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class DateUtil {

    public static DateTimeFormatter formatadorData
            = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    /**
     * Funcao para converter String to LocalDate
     *
     * @param dataString data em string
     * @return String formatada
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static LocalDate stringToDate(String dataString) {
        return (LocalDate.parse(dataString, formatadorData));
    }

    /**
     * Funcao para converter LocalDate to String
     *
     * @param data LocalDate enviada
     * @return LocalDate formatada
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static String dateToString(LocalDate data) {
        return (data.format(formatadorData));
    }

}
