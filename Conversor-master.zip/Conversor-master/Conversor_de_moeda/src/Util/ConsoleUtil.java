package util;

import java.util.Scanner;

/**
 * Classe para uso de pegar dados do teclado digitado no console
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class ConsoleUtil {

    /**
     * Metodo para buscar strings
     *
     * @param out texto enviado texto enviado
     * @return o que foi digitado no console
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static String scanString(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.nextLine());
    }

    /**
     * Metodo para buscar Int
     *
     * @param out texto enviado
     * @return o que foi digitado no console
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static int scanInt(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.nextInt());
    }

    /**
     * Metodo para buscar Double
     *
     * @param out texto enviado
     * @return o que foi digitado no console
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static double scanDouble(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.nextDouble());
    }

    /**
     * Metodo para buscar Float
     *
     * @param out texto enviado
     * @return o que foi digitado no console
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static float scanFloat(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.nextFloat());
    }

    /**
     * Metodo para buscar Boolean
     *
     * @param out texto enviado
     * @return boolean lido pelo Scanner
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static boolean scanBoolean(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.nextBoolean());
    }

    /**
     * Metodo para buscar char
     *
     * @param out texto enviado
     * @return o que foi digitado no console
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public static char scanChar(Object out) {
        System.out.print(out);
        Scanner scanner = new Scanner(System.in);
        return (scanner.next().charAt(0));
    }

}
