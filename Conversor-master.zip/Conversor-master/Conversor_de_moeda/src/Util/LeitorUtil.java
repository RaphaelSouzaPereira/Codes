package util;

import Model.MoedaModel;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * Classe feita para ler o arquivo csv baixado do site criando uma tabela hash
 * com os nomes das moedas como chave para buscar o objeto moeda e pegar os
 * valores de dentro
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class LeitorUtil {

    /**
     * Funcao feita para correr todo o csv e criar os objetos moedas e colocar
     * eles dentro da tabela hash. Trata duas exceções uma para caso não
     * encontre o arquivo outra para caso haja algum erro na leitura do arquivo.
     *
     * @param moedas para ser usado no main
     * @param nomeDasMoedas para ser usado no main
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public void leArquivo(Hashtable<String, MoedaModel> moedas, ArrayList<String> nomeDasMoedas) {
        String csv = "src/arquivo.csv";
        BufferedReader br = null;
        String linha = "";
        String csvDivisor = ";";
        int contador = 0;
        nomeDasMoedas.add(contador, "PULA");
        contador++;
        try {

            br = new BufferedReader(new FileReader(csv));
            while ((linha = br.readLine()) != null) {
                String[] leitura = linha.split(csvDivisor);

                nomeDasMoedas.add(contador, leitura[3]);
                MoedaModel moeda = new MoedaModel(DateUtil.stringToDate(leitura[0]),
                        leitura[1],
                        leitura[2],
                        leitura[3],
                        converteToBigDecimal(leitura[4]),
                        converteToBigDecimal(leitura[5]),
                        converteToBigDecimal(leitura[6]),
                        converteToBigDecimal(leitura[7]));
                moedas.put(leitura[3], moeda);
                if (leitura[3].equals("USD")) {
                    MoedaModel brl = new MoedaModel(DateUtil.stringToDate(leitura[0]),
                            "790",
                            "A",
                            "BRL",
                            converteToBigDecimal("1"),
                            converteToBigDecimal("1"),
                            moeda.getTaxaCompra(),
                            moeda.getTaxaVenda());
                    moedas.put(brl.getMoeda(), brl);
                    contador++;
                    nomeDasMoedas.add(contador, "BRL");
                }

            }

        } catch (FileNotFoundException e) {
            System.out.println("Arquivo nao encontrado.");
        } catch (IOException e) {
            System.out.println("O arquivo nao pode ser lido.");
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    System.out.println("O arquivo nao pode ser fechado.");
                }
            }
        }

    }

    /**
     * Funcao para converter string fora do padrao
     *
     * @param valor da string que será mudado
     * @return valor como bigdecimal já convertido
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    public BigDecimal converteToBigDecimal(String valor) {
        valor = valor.replace(".", "");
        valor = valor.replace(",", ".");
        valor = valor.trim();
        return new BigDecimal(valor);
    }

}
