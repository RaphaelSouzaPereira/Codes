/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacao;

import Aplicacao.ConversorApplicacao;
import Model.MoedaModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Hashtable;
import org.junit.Test;
import static org.junit.Assert.*;
import util.DateUtil;
import util.LeitorUtil;

/**
 *
 * @author RaphaeldeSouzaPereir
 */
public class ConversorApplicacaoTest {

    /**
     * Test of currencyQuotation metodo, da classe ConversorApplicacao.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testCurrencyQuotation() {
        Hashtable<String, MoedaModel> moedas = new Hashtable<String, MoedaModel>();
        ArrayList<String> nomeDasMoedas = new ArrayList<String>();
        System.out.println("currencyQuotation");
        String from = "USD";
        String to = "BRL";
        Number value = 100;
        String quotation = "09/11/2018";
        LeitorUtil csv = new LeitorUtil();
        csv.leArquivo(moedas, nomeDasMoedas);
        ConversorApplicacao instance = new ConversorApplicacao(moedas, nomeDasMoedas);
        BigDecimal expResult = BigDecimal.valueOf(200);
        BigDecimal result = instance.currencyQuotation(from, to, value, quotation);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of atualizaData metodo, da classe ConversorApplicacao.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testAtualizaData(){
        Hashtable<String, MoedaModel> moedas = new Hashtable<String, MoedaModel>();
        ArrayList<String> nomeDasMoedas = new ArrayList<String>();
        ConversorApplicacao instance = new ConversorApplicacao(moedas, nomeDasMoedas);
        LocalDate data = DateUtil.stringToDate("10/11/2018");
        LocalDate expResult = DateUtil.stringToDate("12/11/2018");
        LocalDate result = instance.atualizaData(data);
        assertEquals(expResult, result);        
                
    }
    
    /**
     * Test of validaValue metodo, da classe ConversorApplicacao.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testValidaValue(){
        Hashtable<String, MoedaModel> moedas = new Hashtable<String, MoedaModel>();
        ArrayList<String> nomeDasMoedas = new ArrayList<String>();
        ConversorApplicacao instance = new ConversorApplicacao(moedas, nomeDasMoedas);
        Double valor = 10.0;
        Double expResult = 10.0;
        Double result = (Double) instance.validaValue(valor);
        assertEquals(expResult, result);
    }
}
