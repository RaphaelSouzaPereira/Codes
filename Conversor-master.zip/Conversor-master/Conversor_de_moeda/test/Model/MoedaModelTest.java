/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.Test;
import static org.junit.Assert.*;
import util.DateUtil;

/**
 * Class test para moeda model
 *
 * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
 */
public class MoedaModelTest {

    /**
     * Test of getData metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetData() {
        System.out.println("Test Get Data");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        LocalDate expResult = DateUtil.stringToDate("09/11/2018");
        LocalDate result = instance.getData();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCodMoeda metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetCodMoeda() {
        System.out.println("Test get cod moeda");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        String expResult = "220";
        String result = instance.getCodMoeda();
        assertEquals(expResult, result);

    }

    /**
     * Test of getTipo metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetTipo() {
        System.out.println("Test get tipo");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        String expResult = "A";
        String result = instance.getTipo();
        assertEquals(expResult, result);

    }

    /**
     * Test of getMoeda metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetMoeda() {
        System.out.println("Test get moeda");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        String expResult = "USD";
        String result = instance.getMoeda();
        assertEquals(expResult, result);
    }

    /**
     * Test of getTaxaCompra metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetTaxaCompra() {
        System.out.println("Test get taxa compra");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        BigDecimal expResult = BigDecimal.valueOf(10.00);
        BigDecimal result = instance.getTaxaCompra();
        assertEquals(expResult, result);
    }

    /**
     * Test of getTaxaVenda metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetTaxaVenda() {
        System.out.println("Test get taxa compra");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        BigDecimal expResult = BigDecimal.valueOf(20.00);
        BigDecimal result = instance.getTaxaVenda();
        assertEquals(expResult, result);
    }

    /**
     * Test of getParidadeCompra metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetParidadeCompra() {
        System.out.println("Test get paridade de compra");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        BigDecimal expResult = BigDecimal.valueOf(30.00);
        BigDecimal result = instance.getParidadeCompra();
        assertEquals(expResult, result);

    }

    /**
     * Test of getParidadeVenda metodo, da classe MoedaModel.
     *
     * @author Raphael de Souza Pereira raphaelsouzapereira32@gmail.com
     */
    @Test
    public void testGetParidadeVenda() {
        System.out.println("Teste get paridade de venda");
        MoedaModel instance = new MoedaModel(DateUtil.stringToDate("09/11/2018"),
                "220",
                "A",
                "USD",
                BigDecimal.valueOf(10.00),
                BigDecimal.valueOf(20.00),
                BigDecimal.valueOf(30.00),
                BigDecimal.valueOf(40.00));
        BigDecimal expResult = BigDecimal.valueOf(40.00);
        BigDecimal result = instance.getParidadeVenda();
        assertEquals(expResult, result);

    }

}
