package Aula18112016;

public class Defeito {
	
	String defeito;
	
	public String getDefeito() {
		return defeito;
	}

	public void setDefeito(String defeito) {
		this.defeito = defeito;
	}

	
	
	
}
