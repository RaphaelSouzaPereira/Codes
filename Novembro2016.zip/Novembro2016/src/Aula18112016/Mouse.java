package Aula18112016;

public class Mouse {
	
	int identificacao;
	Defeito defeito;
	
	public int getIdentificacao() {
		return identificacao;
	}
	public void setIdentificacao(int identificacao) {
		this.identificacao = identificacao;
	}
	public Defeito getDefeito() {
		return defeito;
	}
	public void setDefeito(Defeito defeito) {
		this.defeito = defeito;
	}

}
