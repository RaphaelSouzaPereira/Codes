package Aula04112016;

public class Bike {
	
	private int    ano   ;
	private String marca ;
	private int    QtMarchas;
	private String cor   ;
	private double valor ;
	
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public int getQtMarchas() {
		return QtMarchas;
	}
	public void setQtMarchas(int qtMarchas) {
		QtMarchas = qtMarchas;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}

	
	

}
