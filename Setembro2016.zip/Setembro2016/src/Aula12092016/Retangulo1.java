package Aula12092016;

public class Retangulo1 {

	public static void main(String[] args) {

		for (int l = 0; l < 10; l++) {
			System.out.println();
			for (int c = 0; c < 10; c++) {
				System.out.print("*");
			}
		}

	}

}
