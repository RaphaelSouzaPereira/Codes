package Aula30092016;

public class PessoaIvonei2 {
		private String nome;
		private CidadeIvonei2 cidade;
		
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public CidadeIvonei2 getCidade() {
			return cidade;
		}
		public void setCidade(CidadeIvonei2 cidade) {
			this.cidade = cidade;
		}
		public String toString(){
			return "\n...."+nome+"\n...."+cidade;
		}
}//-----------------final classe
