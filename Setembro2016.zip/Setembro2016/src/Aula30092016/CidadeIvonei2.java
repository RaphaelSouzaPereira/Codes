package Aula30092016;

public class CidadeIvonei2 {
	private String nome;

	
	public String getNome() {
		return nome;
	}//-----------------------

	public void setNome(String nome) {
		this.nome = nome;
	}//-----------------------

	public String toString(){
		return nome;
	}
}//------------------final classe
