package Aula02092016;

public class Lampada {
	private boolean lampada;
	
	public void setLampada(boolean lampada){
		this.lampada = lampada;
	}
	
	public boolean getLampada(){
		return this.lampada;
	}
}
