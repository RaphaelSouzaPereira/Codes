package Aula19082016;

public class orienta��oaobjetoexemplo11 {
	private int orienta��oaobjetoexemplo11;//atribui��o da classe
	
	public orienta��oaobjetoexemplo11(){//construtor
		
	}
	
	public void setNumero(int num){
		this.orienta��oaobjetoexemplo11 = num;
	}
	
	public int getNumero(){
		return this.orienta��oaobjetoexemplo11;
	}


	
	
	
	
	
}





