package Aula08082016;
import java.util.Scanner;
public class Exercicio01 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		int n1, n2;
		
		System.out.print("Digite n1: ");
		n1 = entrada.nextInt();
		System.out.print("Digite n2: ");
		n2 = entrada.nextInt();
		
		System.out.println("Vari�vel n1= "+n1+"\nVari�vel n2= "+n2);

	}// final do main
}// final da Classe
