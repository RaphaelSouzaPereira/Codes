package Aula08082016;
import java.util.Scanner;

public class Exercicio03 {

	public static void main(String[] args) {
		Scanner e = new Scanner(System.in);
		
		int v1, v2;
		
		System.out.print("Digite v1: ");
		v1 = e.nextInt();
		System.out.print("Digite v2: ");
		v2 = e.nextInt();

		int soma = v1+v2;
		
		System.out.println("Soma = "+soma);
		System.out.println("Soma = "+v1+v2);
		System.out.println("Soma = "+(v1+v2));
		
	}// final do main

}// final da classe





