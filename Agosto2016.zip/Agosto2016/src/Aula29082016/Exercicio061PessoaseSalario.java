package Aula29082016;

public class Exercicio061PessoaseSalario {
	private String nome;
	private float salario;
	public Exercicio061PessoaseSalario(){
		
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	public String getNome() {
		return this.nome;
	}
	public void setSalario(float salario){
		this.salario = salario;
	}
	public float getSalario(){
		return this.salario;
	}
}
