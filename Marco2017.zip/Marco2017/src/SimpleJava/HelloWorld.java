package SimpleJava;

import com.senac.SimpleJava.Console;

public class HelloWorld {
	public void run(){
	
	Console.println("Hello World");

	}
}
