package Aula21102016;

public class Deputado {
	
	private String nome;
	private Partido partido;
	private int indicadorCorrupcao;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Partido getPartido() {
		return partido;
	}

	public void setPartido(Partido partido) {
		this.partido = partido;
	}
	public int getIndicadorCorrupcao() {
		return indicadorCorrupcao;
	}
	public void setIndicadorCorrupcao(int indicadorCorrupcao) {
		this.indicadorCorrupcao = indicadorCorrupcao;
	}

}
